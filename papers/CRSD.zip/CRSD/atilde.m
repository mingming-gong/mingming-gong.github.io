function Atilde = atilde(A, dim, numLag)

Atilde = zeros(dim, dim*numLag);
for l = 0:numLag-1
    Atilde(:,l*dim+1:(l+1)*dim) = A^l;
end
end