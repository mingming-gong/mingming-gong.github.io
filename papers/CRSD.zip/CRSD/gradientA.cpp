#include <stdlib.h>
#include <math.h>
#include <mex.h>
#include <vector>
#include <limits>
#include <algorithm>
#include <string.h>
#include <fstream>
#include <boost/numeric/ublas/vector.hpp>
#include <boost/numeric/ublas/vector_proxy.hpp>
#include <boost/numeric/ublas/matrix.hpp>
#include <boost/numeric/ublas/matrix_proxy.hpp>
#include <boost/numeric/ublas/vector_expression.hpp>
#include <boost/numeric/ublas/matrix_expression.hpp>
//#include<gsl/gsl_cblas.h>

using namespace std;
namespace ublas = boost::numeric::ublas;
typedef double DBL;
typedef ublas::row_major ORI;

/// print vector
void printVector(ublas::vector<DBL> A, size_t dim)
{
    for(size_t j=0; j < dim; j++)
    {
        cout << A(j) << " ";
    }
    cout << "\n";
}

/// print matrix
void printMatrix(ublas::matrix<DBL, ORI> A, size_t dim1, size_t dim2)
{
    for(size_t j=0; j < dim1; j++)
    {
        for (size_t k = 0; k < dim2; k++)
        {
            cout << A(j,k) << " ";
        }
        cout << "\n";
    }
    cout << "\n";
}

/// load matrix
double* loadPCABasis(string fileName, int Dim, int dim)
{
    double *pcaBasisData = new double[Dim*dim];
    ifstream basisFile(fileName.c_str());
    istringstream istr;
    string str;
    int num = 0;
    while(getline(basisFile,str))
    {
        istr.str(str);
        double tmp;
        while(istr>>tmp)
        {
            pcaBasisData[num++] = tmp;
        }
        istr.clear();
    }
    return pcaBasisData;
}

/// A^k
ublas::matrix<DBL, ORI>* A_PowerK(ublas::matrix<DBL, ORI> A, size_t dim, size_t numLag)
{
    ublas::matrix<DBL, ORI> *A_k = new ublas::matrix<DBL, ORI>[numLag+1];
    ublas::identity_matrix<DBL> identityMatrix(dim, dim);
    for(size_t i = 0; i <= numLag; i++)
        A_k[i] = ublas::matrix<DBL, ORI>(dim, dim);
    A_k[0] = identityMatrix;
    A_k[1] = A;
    for(size_t i = 1; i < numLag; i++)
        A_k[i+1] = prod(A_k[i], A);
    return A_k;
}

/// Atilde
ublas::matrix<DBL, ORI> atilde(ublas::matrix<DBL, ORI> *A_k, size_t dim, const size_t numLag)
{
    ublas::matrix<DBL, ORI> Atilde(dim, dim*numLag);
    for(size_t k = 0; k < numLag; k++)
        for(size_t i = 0; i < dim; i++)
            for(size_t j = 0; j < dim; j++)
            {
                Atilde(i,j+k*dim) = A_k[k](i,j);
            }
    return Atilde;
}

/// trace
double matrixTrace(ublas::matrix<DBL, ORI> A, size_t dim)
{
    double trace = 0;
    for(size_t i = 0; i < dim; i++)
        trace += A(i,i);
    return trace;
}

/// derivative of U with respect to Aijs
ublas::matrix<DBL, ORI>* gradAU(ublas::matrix<DBL, ORI> A, ublas::matrix<DBL, ORI> invLambda,
        size_t dim, size_t numLag, ublas::matrix<DBL, ORI> *A_k)
{
    ublas::zero_matrix<DBL> zeroMatrix(dim, dim);
    ublas::zero_matrix<DBL> zeroMatrixE(dim*numLag, dim*numLag);
    ublas::matrix<DBL, ORI> *gradAijs = new ublas::matrix<DBL, ORI> [dim*dim];
    for(size_t i = 0; i < dim*dim; i++)
        gradAijs[i] = zeroMatrixE;
    ublas::matrix<DBL, ORI> *gradAijUmn1 = new ublas::matrix<DBL, ORI> [dim*dim];
    ublas::matrix<DBL, ORI> *gradAijUmn2 = new ublas::matrix<DBL, ORI> [dim*dim];
    for(size_t i = 0; i < dim*dim; i++)
        gradAijUmn1[i] = zeroMatrix;
    for(size_t i = 0; i < dim*dim; i++)
        gradAijUmn2[i] = zeroMatrix;
    
    for(size_t m = 0; m < numLag; m++)
    {
        ublas::matrix<DBL, ORI> LambdaAm(dim, dim);
        LambdaAm = prod(trans(A_k[m]), invLambda);
        for(size_t n = m; n < numLag; n++)
        {
            ublas::matrix<DBL, ORI> LambdaAn(dim, dim);
            LambdaAn= prod(invLambda, A_k[n]);
            ublas::matrix<DBL, ORI> *gradAijUmn1Left = new ublas::matrix<DBL, ORI>[dim*dim];
            for(size_t i = 0; i < dim*dim; i++)
                gradAijUmn1Left[i] = zeroMatrix;
            
            for (size_t k = 0; k < dim; k++)
                for (size_t l = 0; l < dim; l++)
                    for(size_t l1 = 0; l1 < dim; l1++)
                    {
                        gradAijUmn1Left[k*dim+l](l1,k) = LambdaAn(l1,l);
                    }
            
            for (size_t i = 0; i < dim; i++)
                for(size_t j = 0; j < dim; j++)
                {
                    ublas::matrix<DBL, ORI> gradAm(zeroMatrix);
                    for(size_t r = 0; r < m; r++)
                    {
                        ublas::matrix<DBL, ORI> Ar(A_k[r]);
                        ublas::matrix<DBL, ORI> Amr(A_k[m-1-r]);
                        ublas:: vector<DBL> ArCol(dim);
                        ublas:: vector<DBL> AmrRow(dim);
                        for(size_t r1 = 0; r1 < dim; r1++)
                        {
                            ArCol(r1) = Ar(r1,i);
                            AmrRow(r1) = Amr(j,r1);
                        }
                        gradAm = gradAm + outer_prod(ArCol, AmrRow);
                    }
                    for(size_t k = 0; k < dim; k++)
                        for(size_t l = 0; l < dim; l++)
                        {
                            ublas::matrix<DBL, ORI> gradAijUmn1LeftTemp(dim, dim);
                            gradAijUmn1LeftTemp = prod(trans(gradAijUmn1Left[k*dim+l]), gradAm);
                            gradAijUmn1[i*dim+j](k,l) = matrixTrace(gradAijUmn1LeftTemp, dim);
                        }
                }
            
            ublas::matrix<DBL, ORI> *gradAijUmn2Left = new ublas::matrix<DBL, ORI>[dim*dim];
            for(size_t i = 0; i < dim*dim; i++)
                gradAijUmn2Left[i] = zeroMatrix;
            
            for (size_t k = 0; k < dim; k++)
                for (size_t l = 0; l < dim; l++)
                    for(size_t l1 = 0; l1 < dim; l1++)
                    {
                        gradAijUmn2Left[k*dim+l](l1,l) = LambdaAm(k,l1);
                    }
            
            for (size_t i = 0; i < dim; i++)
                for(size_t j = 0; j < dim; j++)
                {
                    ublas::matrix<DBL, ORI> gradAn(zeroMatrix);
                    for(size_t r = 0; r < n; r++)
                    {
                        ublas::matrix<DBL, ORI> Ar(A_k[r]);
                        ublas::matrix<DBL, ORI> Amr(A_k[n-1-r]);
                        ublas:: vector<DBL> ArCol(dim);
                        ublas:: vector<DBL> AmrRow(dim);
                        for(size_t r1 = 0; r1 < dim; r1++)
                        {
                            ArCol(r1) = Ar(r1,i);
                            AmrRow(r1) = Amr(j,r1);
                        }
                        gradAn = gradAn + outer_prod(ArCol, AmrRow);
                    }
                    for(size_t k = 0; k < dim; k++)
                        for(size_t l = 0; l < dim; l++)
                        {
                            ublas::matrix<DBL, ORI> gradAijUmn2LeftTemp(dim, dim);
                            gradAijUmn2LeftTemp = prod(trans(gradAijUmn2Left[k*dim+l]), gradAn);
                            gradAijUmn2[i*dim+j](k,l) = matrixTrace(gradAijUmn2LeftTemp, dim);
                        }
                }
            
            for(size_t i = 0; i < dim*dim; i++)
                for(size_t r1 = 0; r1 < dim; r1++)
                    for(size_t c1 = 0; c1 < dim; c1++)
                    {
                        if (m == n)
                        {
                            gradAijs[i](m*dim+r1,n*dim+c1) = 0.5 *(gradAijUmn1[i](r1,c1) + gradAijUmn2[i](r1,c1));
                        }
                        else
                        {
                            gradAijs[i](m*dim+r1,n*dim+c1) = gradAijUmn1[i](r1,c1) + gradAijUmn2[i](r1,c1);
                        }
                    }
            delete []gradAijUmn1Left;
            delete []gradAijUmn2Left;
        }
    }
    
    // output
    for(size_t i = 0; i < dim*dim; i++)
        gradAijs[i] = gradAijs[i] + trans(gradAijs[i]);
    
    delete []gradAijUmn1;
    delete []gradAijUmn2;
    return gradAijs;
}

ublas::matrix<DBL, ORI> gradientA_Elem(ublas::matrix<DBL, ORI> A, ublas::matrix<DBL, ORI> Atilde, ublas::matrix<DBL, ORI> *A_k, 
        ublas::matrix<DBL, ORI> invLambda, double *xtp11, double *xt1, double *posMeanE1, double *posCovE1,
        size_t dim, size_t dimE, size_t numLag)
{
    /// copy data to ublas
    ublas::matrix<DBL, ORI> posCovE(dimE, dimE);
    for(size_t i = 0; i < dimE; i++)
        for(size_t j = 0; j < dimE; j++)
        {
            posCovE(i,j) = posCovE1[j*dimE+i];
        }
    
    ublas::vector<DBL> xt(dim);
    ublas::vector<DBL> xtp1(dim);
    ublas::vector<DBL> posMeanE(dimE);
    for(size_t i = 0; i < dim; i++)
        xt(i) = xt1[i];
    for(size_t i = 0; i < dim; i++)
        xtp1(i) = xtp11[i];
    for(size_t i = 0; i < dimE; i++)
        posMeanE(i) = posMeanE1[i];
    
    
    ublas::zero_matrix<DBL> zeroMatrix(dim, dim);
    
    /// gradA1
    ublas::matrix<DBL, ORI> gradA1(dim, dim);
    ublas::matrix<DBL, ORI> gradA1Left(dim, dim);
    gradA1Left = -2 * trans(prod(invLambda, outer_prod(xtp1 - prod(A_k[numLag], xt), xt)));
    for(size_t i = 0; i < dim; i++)
        for(size_t j = 0; j < dim; j++)
        {
            ublas::matrix<DBL, ORI> J(zeroMatrix);
            ublas::matrix<DBL, ORI> gradAk(zeroMatrix);
            ublas::matrix<DBL, ORI> temp(dim, dim);
            J(i,j) = 1;
            for (size_t r = 0; r < numLag; r++)
            {
                temp = prod(J, A_k[numLag-1-r]);
                gradAk = gradAk + prod(A_k[r],temp);
            }
            gradA1(i,j) = matrixTrace(prod(gradA1Left, gradAk), dim);
        }
    
    /// gradA2
    ublas::matrix<DBL, ORI> gradA2(dim, dim);
    ublas::matrix<DBL, ORI> gradA2Left(dim, dim);
    ublas::matrix<DBL, ORI> temp(dim, dim);
    temp = prod(Atilde, outer_prod(posMeanE, xt));
    gradA2Left = - trans(prod(invLambda, temp));
    for(size_t i = 0; i < dim; i++)
        for(size_t j = 0; j < dim; j++)
        {
            ublas::matrix<DBL, ORI> J(zeroMatrix);
            ublas::matrix<DBL, ORI> gradAk(zeroMatrix);
            ublas::matrix<DBL, ORI> temp(dim, dim);
            J(i,j) = 1;
            for (size_t r = 0; r < numLag; r++)
            {
                temp = prod(J, A_k[numLag-1-r]);
                gradAk = gradAk + prod(A_k[r],temp);
            }
            gradA2(i,j) = matrixTrace(prod(gradA2Left, gradAk), dim);
        }
//    printMatrix(gradA2, dim, dim);
     
    /// gradA3
    ublas::matrix<DBL, ORI> gradA3(zeroMatrix);
    if (numLag == 2)
    {
        ublas::vector<DBL> posMeanE_Part((numLag-1)*dim);
        for(size_t i = 0; i < posMeanE_Part.size(); i++)
            posMeanE_Part(i) = posMeanE(i+dim);
        gradA3 = prod(invLambda, outer_prod(xtp1 - prod(A_k[numLag], xt), posMeanE_Part));
//    	printMatrix(gradA3, dim, dim);
    }
    else
    {
        for(size_t l = 1; l < numLag; l++)
        {
            ublas::matrix<DBL, ORI> gradA3Left(zeroMatrix);
            ublas::vector<DBL> posMeanE_Part(dim);
            for(size_t i = 0; i < posMeanE_Part.size(); i++)
                posMeanE_Part(i) = posMeanE(i+l*dim);
            gradA3Left = trans(prod(invLambda, outer_prod(xtp1 - prod(A_k[numLag], xt), posMeanE_Part)));
            for(size_t i = 0; i < dim; i++)
                for(size_t j = 0; j < dim; j++)
                {
                    ublas::matrix<DBL, ORI> J(zeroMatrix);
                    ublas::matrix<DBL, ORI> gradAl(zeroMatrix);
                    ublas::matrix<DBL, ORI> temp(dim, dim);
                    J(i,j) = 1;
                    for (size_t r = 0; r < l; r++)
                    {
                        temp = prod(J, A_k[l-1-r]);
                        gradAl = gradAl + prod(A_k[r],temp);
                    }
                    gradA3(i,j) = gradA3(i,j) + matrixTrace(prod(gradA3Left, gradAl), dim);
                }
        }
//    	printMatrix(gradA3, dim, dim);
    }
    
    /// gradA4
    ublas::matrix<DBL, ORI> gradA4(zeroMatrix);
    if (numLag == 2)
    {
        for(size_t i = 0; i < dim; i++)
            for(size_t j = 0; j < dim; j++)
            {
                ublas::matrix<DBL, ORI> J(zeroMatrix);
                ublas::matrix<DBL, ORI> gradAij(dimE, dimE);
                ublas::matrix<DBL, ORI> temp(dim, dim);
                J(i,j) = 1;
                ublas::matrix<DBL, ORI> *gradAijSub = new ublas::matrix<DBL, ORI>[numLag*numLag];
                for (size_t k = 0; k < numLag*numLag; k++)
                    gradAijSub[k] = ublas::matrix<DBL, ORI>(dim, dim);
                gradAijSub[0] = zeroMatrix;
                gradAijSub[1] = prod(invLambda, J);
                gradAijSub[2] = prod(trans(J), invLambda);
                gradAijSub[3] = prod(trans(A), gradAijSub[1]) + prod(gradAijSub[2], A);
                for(size_t r = 0; r < numLag; r++ )
                    for(size_t c = 0; c < numLag; c++)
                        for(size_t r1 = 0; r1 < dim; r1++)
                            for(size_t c1 = 0; c1 < dim; c1++)
                            {
                                gradAij(r*dim+r1,c*dim+c1) = gradAijSub[r*numLag+c](r1,c1);
                            }
                gradA4(i,j) = matrixTrace(prod(posCovE, gradAij), dimE);
                delete []gradAijSub;
            }
//         printMatrix(gradA4, dim, dim);
    }
    else
    {
        ublas::matrix<DBL, ORI> *gradAijs;
        gradAijs = gradAU(A, invLambda, dim, numLag, A_k);
//         for(size_t i = 0; i < 4; i++)
//             printMatrix(gradAijs[i], dimE, dimE);
        for(size_t i = 0; i < dim; i++)
            for(size_t j = 0; j < dim; j++)
            {
                gradA4(i,j) = matrixTrace(prod(posCovE, gradAijs[i*dim+j]), dimE);
            }
//         printMatrix(gradA4, dim, dim);
        delete []gradAijs;
    }
    ublas::matrix<DBL, ORI> gradA(dim, dim);
    gradA = 0.5 * (gradA1 - 2 * (gradA2 + gradA3) + gradA4);
    return gradA;
}

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    enum
    {
        XTP1 = 0,
        XT,
        AA,
        POSMEANE,
        POSCOVE,
        DIM,
        NUMLAG,
        LAMBDA,
    };
    enum
    {
        GRADA = 0,
    };
    
    // input
    size_t dim = mxGetScalar(prhs[DIM]);
    size_t numLag = mxGetScalar(prhs[NUMLAG]);
    size_t dimE = dim * numLag;
    double *xtp1 = mxGetPr(prhs[XTP1]);
    double *xt = mxGetPr(prhs[XT]);
    double *A1 = mxGetPr(prhs[AA]);
    double *posMeanE = mxGetPr(prhs[POSMEANE]);
    double *posCovE = mxGetPr(prhs[POSCOVE]);
    double *Lambda = mxGetPr(prhs[LAMBDA]);
    
    if (numLag ==1)
        mexErrMsgTxt("k must be larger than 2.") ;
    
    // output
    const mwSize *T = mxGetDimensions(prhs[XT]);
    mwSize ndim = 3;
    mwSize dims[3] = {dim, dim, T[1]};
    plhs[GRADA] = mxCreateNumericArray(ndim, dims, mxDOUBLE_CLASS, mxREAL);
    double *plhsGRADA = mxGetPr(plhs[GRADA]);
    
    
    /// inverse Lambda
    double *invLambda1= new double[dim*dim];
    memcpy(invLambda1, Lambda, dim*dim*sizeof(double));
    for(size_t i = 0; i < dim; i++)
        invLambda1[i*(dim+1)] = 1/Lambda[i*(dim+1)];
    
    ublas::matrix<DBL, ORI> invLambda(dim, dim);
    for(size_t i = 0; i < dim; i++)
        for(size_t j = 0; j < dim; j++)
        {
            invLambda(i,j) = invLambda1[j*dim+i];
        }
    delete []invLambda1;
    
    ublas::matrix<DBL, ORI> A(dim, dim);
    for(size_t i = 0; i < dim; i++)
        for(size_t j = 0; j < dim; j++)
        {
            A(i,j) = A1[j*dim+i];
        }
    ublas::matrix<DBL, ORI> *A_k;
    A_k = A_PowerK(A, dim, numLag);
//     for(size_t i=0; i <= numLag; i++)
//     {
//         printMatrix(A_k[i], dim, dim);
//     }
    
    ublas::matrix<DBL, ORI> Atilde(dim, dimE);
    Atilde = atilde(A_k, dim, numLag);
//    printMatrix(Atilde, dim, dimE);
    
    // process each xt
    ublas::matrix<DBL, ORI> *gradA = new ublas::matrix<DBL, ORI>[T[1]];
    for(size_t t = 0 ; t < T[1]; t++)
    {
        gradA[t] = ublas::matrix<DBL,ORI>(dim,dim);
        gradA[t] = gradientA_Elem(A, Atilde, A_k, invLambda, xtp1, xt, posMeanE, posCovE, dim, dimE, numLag);
        xtp1 += dim;
        xt += dim;
        posMeanE += dimE;
        posCovE += dimE*dimE;
    }
    
    double *gradA_all = new double[dim*dim*T[1]];
    size_t indexer = 0;
    for(size_t t = 0; t < T[1]; t++)
        for(size_t i = 0; i < dim; i++)
            for(size_t j = 0; j < dim; j++)
            {
                gradA_all[indexer] = gradA[t](j,i);
                indexer++;
            }
    memcpy(plhsGRADA, gradA_all, dim*dim*T[1]*sizeof(double));
    
    delete []A_k;
    delete []gradA;
    delete []gradA_all;
}
