% Experiment: evaluate EM algorithm for causal discovery from subsampled data
% clc, clear;

% generate data
n = 2; % dimension
k = 2; % subsample factor
T = 100; % time series length
superSub = 1; % 1 - supergaussian, 0 - subgaussian

if superSub == 1
    % superGaussian
    mu = repmat([0 0],[n,1]);
    w = repmat([0.8 0.2],[n 1]);
    sigma = repmat([0.01 1], [n 1]);
else
    if superSub == 0
        % subGaussian
        mu = repmat([-3 2],[n,1]);
        w = repmat([0.4 0.6],[n 1]);
        sigma = repmat([1 1], [n 1]);
    end
end
rng('default');
% random experiments
for exps_id =1
    A = (rand(n)-0.5);
    p = zeros(n, T*k);
    E = zeros(n, T*k);
    for i = 1:n
        p(i,:) = random('binomial', 1, w(i,2), 1, size(E,2)) + 1;
        for j = 1:2
            EE = mu(i,j) + sigma(i,j) * randn(1,sum(p(i,:)==j));
            E(i,p(i,:)==j) = EE;
        end
    end
    
    x1 = ones(n,T*k);
    for i=2:T*k
        x1(:,i) = A * x1(:,i-1) + E(:,i);
    end
    % x1 = x1 - repmat(mean(x1')', 1,T*k);
    
    % subsampled data
    Et = zeros(n, T);
    for t=2:T
        for j=1:k
            Et(:,t) = Et(:,t) + A^(j-1) * E(:,1+(t-1)*k-(j-1));
        end
    end
    
    x = ones(n,T);
    for i=2:T
        x(:,i) = A^k * x(:,i-1) + Et(:,i) + 0.01*randn(n,1);
    end
    
    AkHat = x(:,2:T) * x(:,1:T-1)' * inv(x(:,1:T-1) * x(:,1:T-1)');
    E_Hat = x(:,2:T) - AkHat*x(:,1:T-1);
    
    %     figure, plot(E(1,:), E(2,:), '.');
    %     figure, plot(Et(1,:), Et(2,:), '.');
    %     figure, plot(E_Hat(1,:), E_Hat(2,:), '.');
    %     figure,
    %     subplot(2,1,1)
    %     plot(x(1,:));
    %     subplot(2,1,2)
    %     plot(x(2,:));
    
    % estimate by CSD
    parsEM.thres = 1e-6;
    parsEM.maxIter = 100;
    parsEM.A = A+0.4*rand(n)-0.2;
    parsEM.AkHat = AkHat;
    parsEM.mu = mu;
    parsEM.sigma = sigma;
    parsEM.w = w;   
    parsEM.noise = 1e-4;
    parsEM.updatePrior = 1;
    parsEM.zeroMean = 0;
    parsEM.fast = 1;
    tic;
    [A_Hat, muHat, sigmaHat, wHat, loglAll] = grangerStockEM(x, 2, k, parsEM);
    figure, plot(loglAll);
    fprintf('mean squre error is %e\n',sum((A(:)-A_Hat(:)).^2)/4);
    toc;
end
