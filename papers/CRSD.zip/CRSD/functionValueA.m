function fvA = functionValueA(xtp1, xt, A, posMeanE, posCovE, numLag, Lambda, hFlag)
% Calculate the function (expectation) value of fA

if hFlag == 0
    Atilde = atilde(A, size(xt,1), numLag);
else
    Atilde = AtoH(A, size(xt,1), numLag);
end
fvA = (xtp1-A^numLag*xt)' / Lambda * (xtp1-A^numLag*xt)...
    - 2 * (xtp1-A^numLag*xt)' / Lambda * Atilde * posMeanE...
    + trace(Atilde' / Lambda * Atilde * posCovE) + log(det(Lambda)) + size(xt,1)*log(2*pi);
fvA = 0.5 * fvA;
end