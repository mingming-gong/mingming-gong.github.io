function [A, mu, sigma, w, loglAll] = grangerStockEM(X, numGauss, numLag, parsEM)

% Em algorithm for causal discovery from subsampled data, e as latent variable
% Inputs:
%       X = data points
%       numGauss = number of Gaussian for each component, p
%       numLag = sumsampling interval, k
%       parsEM = parameters for EM
%           parsEM.thres = convergence threshold of the EM algorithm
%           parsEM.maxIter = maximum EM iterations
%           parsEM.A = initial value of A
%           parsEM.AkHat = initial value of A^k
%           parsEM.mu = initial value of means of MoG
%           parsEM.sigma = initial value of standard diveation of MoG
%           parsEM.w = initial value of mixture weights of MoG
%           parsEM.noise = variance of the assumed small gaussian noise
%           parsEM.updatePrior = whether update prior parameters mu, sigma
%           and w
%           parsEM.zeroMean = whether constrain the mean of noise to zero
%           parsEM.fast = whether use overrelaxed EM to speedup 
% Outputs:
%       A = high resolution mixing matrix
%       sigma = mixture of gaussian parameters for all components
%       w = mixture weights
%       loglAll = loglikelihood values at all iterations
% (c) Code written by Mingming Gong.
%     Only to be used for academic purposes.


[dim, N]=size(X);
thres = parsEM.thres;

%% set parameters, initialization
A = parsEM.A;
mu = parsEM.mu;
sigma = parsEM.sigma;
w = parsEM.w;

Lambda = parsEM.noise*eye(dim);
mus = repmat(mu, [numLag,1]);
sigmas = repmat(sigma, [numLag,1]);

%% first E-step
qidMat = qidMatrix(numGauss, numLag, dim);
priorq = priorLatentQ(w, dim, numGauss, numLag, qidMat);

% posterior of q and e
[posq, marginalx] = evaluateQ_Fast(X, A, mus, sigmas, dim, numGauss, numLag, qidMat, priorq,Lambda);
[posMeanE, posCovE, posMeanEqi, posCovEqi] = evaluateE_Fast(X, posq, A, Lambda, ...
    mus, sigmas, dim, numGauss, numLag, qidMat);

% update parameters
logl = -sum(log(marginalx));
if isfield(parsEM,'logl')
    loglAll = logl;
    return;
end
logl_prev = logl;
iter = 0;
fprintf('iter%d: negative loglik: %.10f\n', iter, logl);
A
mu
sigma
w
iter = iter + 1;
loglAll = [];
loglAll = [loglAll, logl];
if parsEM.fast == 0
    alpha = 1;
else
    alpha = 1.2;
end
eta = 1;
A_Prev = A;
%% main loop
while iter == 1 || iter < parsEM.maxIter && abs(logl_prev-logl) >= abs(logl_prev)*thres
    delta = (logl_prev-logl)/abs(logl_prev);
    if delta < thres && iter~=1 && parsEM.fast == 1
        fprintf('adjust eta\n');
        eta = 1;
        A = A_EM;
        qidMat = qidMatrix(numGauss, numLag, dim);
        priorq = priorLatentQ(w, dim, numGauss, numLag, qidMat);
        
        % posterior of q and e
        [posq, marginalx] = evaluateQ_Fast(X, A, mus, sigmas, dim, numGauss, numLag, qidMat, priorq,Lambda);
        [posMeanE, posCovE, posMeanEqi, posCovEqi] = evaluateE_Fast(X, posq, A, Lambda, ...
            mus, sigmas, dim, numGauss, numLag, qidMat);
        
        logl = -sum(log(marginalx));
        loglAll(end) = logl;
        logl_prev = logl;
    else
        eta = eta * alpha;
        logl_prev = logl;
    end
    %% M step
    % update A
    if numLag == 1
        sumXtXt = X(:,1:N-1) * X(:,1:N-1)';
        sumXtp1Xt = X(:,2:N) * X(:,1:N-1)';
        sumEXt = posMeanE(:,1:N-1) * X(:,1:N-1)';
        A_EM = (sumXtp1Xt - sumEXt) / sumXtXt;
    else
        pars.dim = dim;
        pars.numLag = numLag;
        pars.Lambda = Lambda;
        A1 = minimize(A(:), 'fStockGradientA', 10, X, posMeanE, posCovE, pars);
        %         A1 = steepdes('fStockGradientA', A(:), 1, X, posMeanE, posCovE, pars);
        A_EM = reshape(A1(1:dim^2),size(A));
    end
    A = A_Prev + eta*(A_EM-A_Prev);
    A_Prev = A;
    
    if parsEM.updatePrior == 1
        posqi = marginalPosQ(posq, dim, numLag, numGauss, qidMat, 0);
        if parsEM.zeroMean == 0
            % unconstrained mean
            % update mu
            if mu~=zeros(dim,numGauss) % if initial mu is zero, do not update
                mu = updateMu(posqi, posMeanEqi, numGauss, numLag, dim);
                mus = repmat(mu, [numLag, 1]);
            end
            
            % update sigma
            sigma = updateSigma(mu, posqi, posCovEqi, numGauss, numLag, dim);
            sigmas = repmat(sigma, [numLag,1]);
            
            % update w
            w = updateW(posqi, numGauss, numLag, dim);
        else
            if mu~=zeros(dim,numGauss)
                % zero mean constraint
                % update w and mu
                muW = [mu(:); w(:)];
                Aeq = zeros(dim, length(muW));
                for i = 1:dim
                    Aeq(i,dim*numGauss+i:dim:end) = 1;
                end
                beq = ones(dim,1);
                [muW_Hat, fval] = fmincon(@ (muW) jointMu_W (muW, sigmas, posqi, ...
                    posMeanEqi, numLag, numGauss, dim), muW, [], [], Aeq, beq, ...
                    [], [], @(muW) mycon(muW, dim));
                mu = reshape(muW_Hat(1:dim*numGauss),[dim, numGauss]);
                w = reshape(muW_Hat(dim*numGauss+1:end),[dim, numGauss]);
                mus = repmat(mu, [numLag, 1]);
                
                % update sigma
                sigma = updateSigmaZeroMean(mu, posqi, posMeanEqi, posCovEqi, numGauss, numLag, dim);
                sigmas = repmat(sigma, [numLag,1]);
            else
                % update sigma
                sigma = updateSigma(mu, posqi, posCovEqi, numGauss, numLag, dim);
                sigmas = repmat(sigma, [numLag,1]);
                
                % update w
                w = updateW(posqi, numGauss, numLag, dim);
            end
        end
    end
    %% E step
    fprintf('E step\n');
    qidMat = qidMatrix(numGauss, numLag, dim);
    priorq = priorLatentQ(w, dim, numGauss, numLag, qidMat);
    
    % posterior of q and e
    [posq, marginalx] = evaluateQ_Fast(X, A, mus, sigmas, dim, numGauss, numLag, qidMat, priorq,Lambda);
    [posMeanE, posCovE, posMeanEqi, posCovEqi] = evaluateE_Fast(X, posq, A, Lambda, ...
        mus, sigmas, dim, numGauss, numLag, qidMat);
    
    logl = -sum(log(marginalx));
    fprintf('iter%d: negative loglik: %.10f\n', iter, logl);
    
    A
    mu
    sigma
    w
    iter = iter + 1;
    loglAll = [loglAll, logl];
end
end

function [c,ceq] = mycon(x, dim)
% zero mean constraints
numGauss = length(x)/2/dim;
A = zeros(length(x), length(x), dim);
c = [];
ceq = zeros(dim,1);
for i = 1:size(A,3)
    for j = 1:numGauss
        A(i+(j-1)*dim,i+(j-1)*dim+length(x)/2,i) = 1;
    end
    ceq(i) = x'*A(:,:,i)*x;
end
end

function fval = jointMu_W(muW, sigmas, posqi, posMeanEqi, numLag, numGauss, dim)
% joint objective function of mu and w
mu = reshape(muW(1:dim*numGauss),[dim, numGauss]);
w = reshape(muW(1+dim*numGauss:end),[dim, numGauss]);
T = size(posMeanEqi,3);
mus = repmat(mu, [numLag, 1]);
ws = repmat(w, [numLag, 1]);

fvalMu = -0.5 * (-2*posMeanEqi.*repmat(mus,[1 1 T]) + posqi.*(repmat(mus,[1 1 T]).^2)) ./ repmat(sigmas, [1 1 T]).^2;
fvalW = posqi.* log(repmat(ws, [1 1 T]));

fval = -sum(fvalMu(:)) - sum(fvalW(:));
end

function w = updateW(posqi, numGauss, numLag, dim)
% update w

% the posterior of qi
posqi = sum(posqi,3)/size(posqi,3);

w = zeros(dim, numGauss);
for i = 1:dim
    w(i,:) = mean(posqi(i:dim:dim*numLag,:),1);
end
end

function mu = updateMu(posqi, posMeanEqi, numGauss, numLag, dim)
% update mu

% the posterior of qi
posMeanEqi = sum(posMeanEqi,3);
posqi = sum(posqi,3);
mu = zeros(dim, numGauss);
posqii = zeros(dim, numGauss);
for i = 1:dim
    mu(i,:) = sum(posMeanEqi(i:dim:dim*numLag,:),1);
    posqii(i,:) = sum(posqi(i:dim:dim*numLag,:),1);
end
mu = mu./(posqii+eps^20);
end

function sigma = updateSigma(mu, posqi, posCovEqi, numGauss, numLag, dim)
% update sigma

% the posterior of qi
posCovEqi = sum(posCovEqi,3);
posqi = sum(posqi,3);
sigma = zeros(dim, numGauss);
posqii = zeros(dim, numGauss);
for i = 1:dim
    sigma(i,:) = sum(posCovEqi(i:dim:dim*numLag,:),1);
    posqii(i,:) = sum(posqi(i:dim:dim*numLag,:),1);
end
sigma = sigma./(posqii+eps^20)-mu.^2;
sigma = sigma.^0.5;
end

function sigma = updateSigmaZeroMean(mu, posqi, posMeanEqi, posCovEqi, numGauss, numLag, dim)
% update sigma in the zero mean contraint

% the posterior of qi
posMeanEqi = sum(posMeanEqi,3);
posCovEqi = sum(posCovEqi,3);
posqi = sum(posqi,3);
mu1 = zeros(dim, numGauss);
sigma = zeros(dim, numGauss);
posqii = zeros(dim, numGauss);
for i = 1:dim
    mu1(i,:) = sum(posMeanEqi(i:dim:dim*numLag,:),1);
    sigma(i,:) = sum(posCovEqi(i:dim:dim*numLag,:),1);
    posqii(i,:) = sum(posqi(i:dim:dim*numLag,:),1);
end
sigma = (sigma-2*mu1.*mu)./(posqii+eps^20) + mu.^2;
sigma = sigma.^0.5;
end

function [posMeanE, posCovE, posMeanEqi, posCovEqi, posCovEq1] = evaluateE_Fast(X, posq, A, Lambda, ...
    mus, sigmas, dim, numGauss, numLag, qidMat)
% fast E-step
N = size(X,2);
Atilde = atilde(A, dim, numLag);
posMeanE = zeros(numLag*dim, N-1, numGauss^(numLag*dim));
posCovEq = zeros(numLag*dim, numLag*dim, N-1, numGauss^(numLag*dim));
posCovEq1 = zeros(numLag*dim, numLag*dim, numGauss^(numLag*dim));
posMeanEqi = zeros(numLag*dim, numGauss, N-1);
posCovEqi = zeros(numLag*dim, numGauss, N-1);
Y = X(:,2:end) - A^numLag*X(:,1:end-1);

for q = 1:size(posMeanE,3)
    sigmaq = zeros(1,size(qidMat,2));
    muq = zeros(1,size(qidMat,2));
    for j = 1:size(qidMat,2)
        sigmaq(j) = sigmas(j,qidMat(q,j));
        muq(j) = mus(j,qidMat(q,j));
    end
    sigmaq = sigmaq.^2;
    muq = repmat(muq',[1, N-1]);
    posMeanE(:,:,q) = muq + diag(sigmaq) * Atilde' * ((Atilde*diag(sigmaq)*Atilde'+Lambda) \ (Y-Atilde*muq));
    posCovEq1(:,:,q) = (diag(sigmaq) - diag(sigmaq)*Atilde'*...
        ((Atilde*diag(sigmaq)*Atilde'+Lambda) \ Atilde * diag(sigmaq)));
    for t = 1:N-1
        posCovEq(:,:,t,q) = posCovEq1(:,:,q) + posMeanE(:,t,q)*posMeanE(:,t,q)';
    end
    posMeanE(:,:,q) = repmat(posq(:,q)',[numLag*dim 1]) .* posMeanE(:,:,q);
end

for t = 1:N-1
    for i = 1:size(posMeanEqi,1)
        for j = 1:size(posMeanEqi,2)
            ind = qidMat(:,i)==j;
            posMeanEqi(i,j,t) = sum(ind.*squeeze(posMeanE(i,t,:)));
        end
    end
end

posMeanE = sum(posMeanE,3);

for t = 1:N-1
    for i = 1:size(posCovEqi,1)
        for j = 1:size(posCovEqi,2)
            ind = qidMat(:,i)==j;
            posCovEqi(i,j,t) = sum(posq(t,ind)'.*squeeze(posCovEq(i,i,t,ind)));
        end
    end
end

for q = 1:size(posCovEq,4)
    posCovEq(:,:,:,q) = repmat(reshape(posq(:,q),[ 1 1 N-1]), [numLag*dim numLag*dim 1]) .* posCovEq(:,:,:,q);
end
posCovE = sum(posCovEq,4);
end

function [posq, marginalx] = evaluateQ_Fast(X, A, mus, sigmas, dim, numGauss, numLag, qidMat, priorq, Lambda)
% fast E-step
N = size(X,2);
Y = X(:,2:end) - A^numLag*X(:,1:end-1);
Atilde = atilde(A, dim, numLag);
condProb = zeros(N-1, numGauss^(numLag*dim));
for q = 1:size(condProb,2)
    muq = zeros(1,size(qidMat,2));
    sigmaq = zeros(1,size(qidMat,2));
    for j = 1:size(qidMat,2)
        muq(j) = mus(j,qidMat(q,j));
        sigmaq(j) = sigmas(j,qidMat(q,j));
    end
    muq = repmat(Atilde * muq',[1 N-1]);
    U = Atilde * diag(sigmaq.^2) * Atilde' + Lambda;
    condProb(:,q) = (2*pi)^(-size(X,1)*0.5) * det(U)^-0.5 * exp(-0.5*diag((Y-muq)'*inv(U)*(Y-muq)));
end
marginalx = sum(condProb.*repmat(priorq,[N-1,1]),2);
posq = condProb .* repmat(priorq,[N-1,1]) ./ repmat((marginalx+eps^20),[1 size(qidMat,1)]);
end

function priorq = priorLatentQ(w, dim, numGauss, numLag, qidMat)
% Calculate the prior distribution of q

% repeat the parameters for all time lags
ws = repmat(w, [numLag,1]);

priorq = zeros(1, numGauss^(numLag*dim));

for q = 1:length(priorq)
    wq = zeros(1,size(qidMat,2));
    for j = 1:size(qidMat,2)
        wq(j) = ws(j,qidMat(q,j));
    end
    priorq(q) = prod(wq);
end
end