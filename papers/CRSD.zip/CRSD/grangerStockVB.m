function [A, mu, sigma, w, fVal_all] = grangerStockVB(X, numGauss, numLag, parsEM)

% Variational inference algorithm for causal discovery from subsampled data, e as latent variable
% Inputs:
%       X = data points
%       numGauss = number of Gaussian for each component, p
%       numLag = sumsampling interval, k
%       parsEM = parameters for EM
%           parsEM.thres = convergence threshold of the EM algorithm
%           parsEM.maxIter = maximum EM iterations
%           parsEM.A = initial value of A
%           parsEM.AkHat = initial value of A^k
%           parsEM.mu = initial value of means of MoG
%           parsEM.sigma = initial value of standard diveation of MoG
%           parsEM.w = initial value of mixture weights of MoG
%           parsEM.noise = variance of the assumed small gaussian noise
%           parsEM.updatePrior = whether update prior parameters mu, sigma
%           and w
%           parsEM.zeroMean = whether constrain the mean of noise to zero
%           parsEM.fast = whether use overrelaxed EM to speedup 
% Outputs:
%       A = high resolution mixing matrix
%       sigma = mixture of gaussian parameters for all components
%       w = mixture weights
%       fVal_all = loglikelihood values at all iterations
% (c) Code written by Mingming Gong.
%     Only to be used for academic purposes.


[dim, N]=size(X);
thres = parsEM.thres;

A = parsEM.A;
mu = parsEM.mu;
sigma = parsEM.sigma;
w = parsEM.w;

Lambda = parsEM.noise*eye(dim);
sigmas = repmat(sigma, [numLag,1]);
mus = repmat(mu, [numLag,1]);

%% first E-step
% initiate posq
priorqi = repmat(w, [numLag, 1]);
posqi = repmat(priorqi, [1,1,N-1]);

% posterior of q and e
iter0 = 0;
[posMeanE, posCovE, posCovE0, SigmaHat] = evaluateE(X, posqi, A, Lambda, mus, sigmas, numLag);
fVal0 = stockVBLowerBound(X, A, w, posqi, posMeanE, posCovE, posCovE0, mus, sigmas, SigmaHat, numLag, Lambda);
fVal0_prev = fVal0;
while iter0 < 1 ||abs(fVal0_prev-fVal0) >= abs(fVal0_prev)*thres
    fVal0_prev = fVal0;
    % alternate between e and q
    posqi = evaluateQ(X, w, posMeanE, posCovE, mus, sigmas, numLag);
    [posMeanE, posCovE, posCovE0, SigmaHat] = evaluateE(X, posqi, A, Lambda, mus, sigmas, numLag);
    fVal0 = stockVBLowerBound(X, A, w, posqi, posMeanE, posCovE, posCovE0, mus, sigmas, SigmaHat, numLag, Lambda);
    iter0 = iter0 + 1;
end
% fVal0_prev-fVal0

fVal = fVal0;

if isfield(parsEM,'logl')
    fVal_all = fVal;
    return;
end
fVal_prev = fVal;
iter = 0;
fprintf('iter%d: neg log likelihood: %f\n', iter, fVal);
A
mu
sigma
w
iter = iter+1;
fVal_all = [];
fVal_all = [fVal_all, fVal];

eta = 1;
if parsEM.fast == 0
    alpha = 1;
else
    alpha = 1.2;
end

A_Prev = A;
%% main loop
while iter == 1 || iter < parsEM.maxIter && abs(fVal_prev-fVal) >= abs(fVal_prev)*thres
    delta = (fVal_prev-fVal)/abs(fVal_prev);
    
    if delta < thres && iter~=1 && parsEM.fast == 1
        eta = 1;
        A = A_EM;
        % posterior of q and e
        fVal0_prev = fVal_prev;
        fVal0 = fVal_prev;
        iter0 = 0;
        while iter0 < 1 || abs(fVal0_prev-fVal0) >= abs(fVal0_prev)*thres
            fVal0_prev = fVal0;
            % alternate between e and q
            posqi = evaluateQ(X, w, posMeanE_prev, posCovE_prev, mus, sigmas, numLag);
            [posMeanE, posCovE, posCovE0, SigmaHat] = evaluateE(X, posqi, A, Lambda, mus, sigmas, numLag);
            fVal0 = stockVBLowerBound(X, A, w, posqi, posMeanE, posCovE, posCovE0, mus, sigmas, SigmaHat, numLag, Lambda);
            iter0 = iter0 + 1;
        end
        
        fVal = fVal0;
        fVal_all(end) = fVal;
        fVal_prev = fVal;
    else
        eta = eta * alpha;
        fVal_prev = fVal;
    end
    %% M step
    % update A and sigma
    % update A
    if numLag == 1
        sumXtXt = X(:,1:N-1) * X(:,1:N-1)';
        sumXtp1Xt = X(:,2:N) * X(:,1:N-1)';
        sumEXt = posMeanE(:,1:N-1) * X(:,1:N-1)';
        A_EM = (sumXtp1Xt - sumEXt) / sumXtXt;
    else
        pars.dim = dim;
        pars.numLag = numLag;
        pars.Lambda = Lambda;
        A1 = minimize(A(:), 'fStockGradientA', 5, X, posMeanE, posCovE, pars);
        A_EM = reshape(A1(1:dim^2),size(A));
    end
    A = A_Prev + eta*(A_EM-A_Prev);
    A_Prev = A;
    
    if parsEM.updatePrior == 1
        if parsEM.zeroMean == 0
            % unconstrained mean
            % update mu
            if mu~=zeros(dim,numGauss) % if initial mu is zero, do not update
                mu = updateMu(posqi, posMeanE, numGauss, numLag, dim);
                mus = repmat(mu, [numLag, 1]);
            end
            % update sigma
            sigma = updateSigma(mu, posqi, posCovE, numGauss, numLag, dim);
            sigmas = repmat(sigma, [numLag,1]);
            
            % update w
            w = updateW(posqi, numGauss, numLag, dim);
        else if mu~=zeros(dim,numGauss)
                % zero mean constraint
                % update w and mu
                muW = [mu(:); w(:)];
                Aeq = zeros(dim, length(muW));
                for i = 1:dim
                    Aeq(i,dim*numGauss+i:dim:end) = 1;
                end
                beq = ones(dim,1);
                [muW_Hat, fval] = fmincon(@ (muW) jointMu_W (muW, sigmas, posqi, ...
                    posMeanE, numLag, numGauss, dim), muW, [], [], Aeq, beq, ...
                    [], [], @(muW) mycon(muW, dim));
                mu = reshape(muW_Hat(1:dim*numGauss),[dim, numGauss]);
                w = reshape(muW_Hat(dim*numGauss+1:end),[dim, numGauss]);
                mus = repmat(mu, [numLag, 1]);
                % update sigma
                sigma = updateSigmaZeroMean(mu, posqi, posMeanE, posCovE, numGauss, numLag, dim);
                sigmas = repmat(sigma, [numLag,1]);
            else
                % update sigma
                sigma = updateSigma(mu, posqi, posCovE, numGauss, numLag, dim);
                sigmas = repmat(sigma, [numLag,1]);
                
                % update w
                w = updateW(posqi, numGauss, numLag, dim);
            end
        end
    end
    
    %% E step
    
    % posterior of q and e
    fVal0_prev = fVal_prev;
    fVal0 = fVal_prev;
    posMeanE_prev = posMeanE;
    posCovE_prev = posCovE;
    iter0 = 0;
    while iter0 < 1 ||abs(fVal0_prev-fVal0) >= abs(fVal0_prev)*thres
        fVal0_prev = fVal0;
        % alternate between e and q
        posqi = evaluateQ(X, w, posMeanE, posCovE, mus, sigmas, numLag);
        [posMeanE, posCovE, posCovE0, SigmaHat] = evaluateE(X, posqi, A, Lambda, mus, sigmas, numLag);
        fVal0 = stockVBLowerBound(X, A, w, posqi, posMeanE, posCovE, posCovE0, mus, sigmas, SigmaHat, numLag, Lambda);
        iter0 = iter0 + 1;
    end
    
    fVal = fVal0;
    fprintf('iter%d: neg log likelihood: %f\n', iter, fVal);
    fVal_all = [fVal_all, fVal];
    A
    mu
    sigma
    w
    iter = iter + 1;
end
end

function [c,ceq] = mycon(x, dim)
% zero mean constraints
numGauss = length(x)/2/dim;
A = zeros(length(x), length(x), dim);
c = [];
ceq = zeros(dim,1);
for i = 1:size(A,3)
    for j = 1:numGauss
        A(i+(j-1)*dim,i+(j-1)*dim+length(x)/2,i) = 1;
    end
    ceq(i) = x'*A(:,:,i)*x;
end
end

function fval = jointMu_W(muW, sigmas, posqi, posMeanE, numLag, numGauss, dim)
% joint objective function of mu and w
posMeanEqi = repmat(reshape(posMeanE,[numLag*dim 1 size(posMeanE,2)]),[1 2 1]);
posMeanEqi = posqi.*posMeanEqi;
mu = reshape(muW(1:dim*numGauss),[dim, numGauss]);
w = reshape(muW(1+dim*numGauss:end),[dim, numGauss]);
T = size(posMeanEqi,3);
mus = repmat(mu, [numLag, 1]);
ws = repmat(w, [numLag, 1]);

fvalMu = -0.5 * (-2*posMeanEqi.*repmat(mus,[1 1 T]) + posqi.*(repmat(mus,[1 1 T]).^2)) ./ (repmat(sigmas, [1 1 T]).^2);
fvalW = posqi.* log(repmat(ws, [1 1 T]));

fval = -sum(fvalMu(:)) - sum(fvalW(:));
end

function w = updateW(posqi, numGauss, numLag, dim)
% Update w
% the posterior of qi
posqi = sum(posqi,3)/size(posqi,3);
w = zeros(dim, numGauss);
for i = 1:dim
    w(i,:) = mean(posqi(i:dim:dim*numLag,:),1);
end
end


function mu = updateMu(posqi, posMeanE, numGauss, numLag, dim)
% update mu

posMeanEqi = repmat(reshape(posMeanE,[numLag*dim 1 size(posMeanE,2)]),[1 2 1]);

mus = posqi.*posMeanEqi;
mus = sum(mus, 3);
mu = zeros(dim, numGauss);
for i = 1:dim
    mu(i,:) = sum(mus(i:dim:dim*numLag,:),1);
end

posqi = sum(posqi, 3);
posqi11 = zeros(dim, numGauss);
for i = 1:dim
    posqi11(i,:) = sum(posqi(i:dim:dim*numLag,:),1);
end

mu = mu./posqi11;
end

function sigma = updateSigma(mu, posqi, posCovE, numGauss, numLag, dim)
% Update sigma

% the posterior of qi
posCovEi = zeros(size(posCovE,1),1,size(posCovE,3));
for i = 1:size(posCovEi,3)
    posCovEi(:,:,i) = diag(posCovE(:,:,i));
end
posCovEqi = repmat(posCovEi,[1 2 1]);

sigmas = posqi.*posCovEqi;
sigmas = sum(sigmas, 3);
sigma = zeros(dim, numGauss);
for i = 1:dim
    sigma(i,:) = sum(sigmas(i:dim:dim*numLag,:),1);
end

posqi = sum(posqi, 3);
posqi11 = zeros(dim, numGauss);
for i = 1:dim
    posqi11(i,:) = sum(posqi(i:dim:dim*numLag,:),1);
end

sigma = sigma./posqi11 - mu.^2;
sigma = sigma.^0.5;
end

function sigma = updateSigmaZeroMean(mu, posqi, posMeanE, posCovE, numGauss, numLag, dim)
% update sigma in the zero mean contraint

% the posterior of qi
posMeanEqi = repmat(reshape(posMeanE,[numLag*dim 1 size(posMeanE,2)]),[1 2 1]);
posCovEi = zeros(size(posMeanE,1),1,size(posMeanE,2));
for i = 1:size(posCovEi,3)
    posCovEi(:,:,i) = diag(posCovE(:,:,i));
end
posCovEqi = repmat(posCovEi,[1 2 1]);

posMeanEqi = sum(posMeanEqi.*posqi,3);
posCovEqi = sum(posCovEqi.*posqi,3);
posqi = sum(posqi,3);
mu1 = zeros(dim, numGauss);
sigma = zeros(dim, numGauss);
posqii = zeros(dim, numGauss);
for i = 1:dim
    mu1(i,:) = sum(posMeanEqi(i:dim:dim*numLag,:),1);
    sigma(i,:) = sum(posCovEqi(i:dim:dim*numLag,:),1);
    posqii(i,:) = sum(posqi(i:dim:dim*numLag,:),1);
end
sigma = (sigma-2*mu1.*mu)./(posqii+eps^20) + mu.^2;
sigma = sigma.^0.5;
end


function [posMeanE, posCovE, posCovE0, SigmaHat] = evaluateE(X, posqi, A, Lambda, mus, sigmas, numLag)
% Posterior of E

[dim, N] = size(X);
Atilde = atilde(A, dim, numLag);
SigmaHat = zeros(numLag*dim, numLag*dim, N-1);
% variational parameters
% for t = 1:N-1
%     for i = 1:numLag*dim
%         SigmaHat(i,i,t) = 1/sum(1./sigmas(i,:).^2 .* posqi(i,:,t));
%     end
% end
sigmaTmp = 1/sum(1/repmat(sigmas.^2,[1 1 N-1]) .* posqi, 2);
for t = 1:N-1
    SigmaHat(:,:,t) = diag(sigmaTmp(:,:,t));
end

meanHat = sigmaTmp .* sum(repmat(mus,[1 1 N-1])./repmat(sigmas.^2,[1 1 N-1]) .* posqi, 2);
Y = X(:,2:end) - A^numLag*X(:,1:end-1);
posMeanE = zeros(dim*numLag, N-1);
posCovE = zeros(dim*numLag, dim*numLag, N-1);
posCovE0 = zeros(dim*numLag, dim*numLag, N-1);
for t = 1:N-1
    posMeanE(:,t) = meanHat(:,t) + SigmaHat(:,:,t) * Atilde' * inv(Atilde*SigmaHat(:,:,t)*Atilde'+Lambda) * (Y(:,t)-Atilde*meanHat(:,t));
    posCovE0(:,:,t) = (SigmaHat(:,:,t) - SigmaHat(:,:,t)*Atilde'*...
        ((Atilde*SigmaHat(:,:,t)*Atilde'+Lambda) \ Atilde * SigmaHat(:,:,t)));
    posCovE(:,:,t) = posCovE0(:,:,t)+ posMeanE(:,t)*posMeanE(:,t)';
end
end

function posqi = evaluateQ(X, w, posMeanE, posCovE, mus, sigmas, numLag)
% Posterior distribution of latent variable q

[dim, N] = size(X);
ws = repmat(w, [numLag,1]);
posqi = zeros(numLag*dim, size(ws,2), N-1);
for t = 1:N-1
    condProb = conditionalProb(mus, sigmas, posMeanE(:,t), posCovE(:,:,t));
    posqi(:,:,t) = condProb.*ws(1:numLag*dim,:)./repmat(sum(condProb.*ws(1:numLag*dim,:),2),[1 size(ws,2)]);
end
end

function condProb = conditionalProb(mus, sigmas, posMeanEt, posCovEt)
% Conditional probability p(x_tp1|xtp,q)
logCondProb = -0.5 * ((repmat(diag(posCovEt),[1 size(sigmas,2)]) + mus.^2 - 2*mus.*repmat(posMeanEt,[1 size(sigmas,2)]))./(sigmas.^2) + 2*log(sigmas));
condProb = exp(logCondProb);
[maxRow, maxRowIdx] = max(logCondProb,[],2);
logCondProb(maxRow>700,:) = logCondProb(maxRow>700,:) - repmat(maxRow(maxRow>700,:),[1 size(sigmas,2)]) + 700;
condProb(maxRow>700,:) = exp(logCondProb(maxRow>700,:));
[minRow, minRowIdx] = min(logCondProb,[],2);
logCondProb(minRow<-700,:) = logCondProb(minRow<-700,:) - repmat(minRow(minRow<-700,:),[1 size(sigmas,2)]) - 700;
condProb(minRow<-700,:) = exp(logCondProb(minRow<-700,:));
condProb(logCondProb>700) = exp(700);

% for i = 1:size(condProb,1)
%     if max(condProb(i,:)) > exp(700)
%         maxLogCondProb = max(logCondProb(i,:));
%         logCondProb(i,:) = logCondProb(i,:) - maxLogCondProb + 700;
%         condProb(i,:) = exp(logCondProb(i,:));
%     end
%     if max(condProb(i,:)) < exp(-100)
%         maxLogCondProb = max(logCondProb(i,:));
%         logCondProb(i,:) = logCondProb(i,:) - maxLogCondProb + 300;
%         condProb(i,:) = exp(logCondProb(i,:));
%     end
% end
end