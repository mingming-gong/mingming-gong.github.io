function qidMat = qidMatrix(numGauss, numLag, dim)
% Get all the qs

qidMat = zeros(numGauss^(numLag*dim), numLag*dim);
for i = size(qidMat,2):-1:1
    id = size(qidMat,2) - i;
    qidMatTemp = [];
    for j = 1:numGauss
        qidMatTemp = [qidMatTemp; j*ones(numGauss^id,1)];
    end
    qidMat(:,i) = repmat(qidMatTemp, [numGauss^(numLag*dim-id-1),1]);
end
end