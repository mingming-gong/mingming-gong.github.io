function priorq = priorLatentQ(w, dim, numGauss, numLag, qidMat)
% Calculate the prior distribution of q

% repeat the parameters for all time lags
ws = repmat(w, [numLag,1]);

priorq = zeros(1, numGauss^(numLag*dim));

for q = 1:length(priorq)
    wq = zeros(1,size(qidMat,2));
    for j = 1:size(qidMat,2)
        wq(j) = ws(j,qidMat(q,j));
    end
    priorq(q) = prod(wq);
end
end