function [fVal] = stockEmLowerBound(X, A, posq, mu, posMeanE, posCovE, posMeanEqi, posCovEqi, posCovEq, w, sigmas, numLag, numGauss, Lambda, qidMat)
% The negative lower bound function value

[dim, N] = size(X);
posqi = marginalPosQ(posq, dim, numLag, numGauss, qidMat, 0);

fvq = 0;
ws = repmat(w, [numLag,1]);
for t = 1:N-1
    for i = 1:numGauss
        fvq = fvq - sum(log(ws(1:numLag*dim,i)).*posqi(:,i,t));
    end
end

fvA = 0;
for t = 1:N-1
    fvA = fvA + functionValueA(X(:,t+1), X(:,t), A, posMeanE(:,t), posCovE(:,:,t), numLag, Lambda, 0);
end

fvE = 0;
for t = 1:N-1
    for i = 1:size(posqi,1)
        for j = 1:size(posqi,2)
            fvE = fvE + (posCovEqi(i,j,t)+mu(i,j)^2-2*posMeanEqi(i,j,t)*mu(i,j))/(sigmas(i,j)^2) +...
                posqi(i,j,t) *(2 * log(sigmas(i,j)) + log(2*pi));
        end
    end
end

fvH = 0;
for t = 1:N-1
    for q = 1:size(qidMat,1)
        if posq(t,q)~=0
            fvH = fvH + posq(t,q) * log(posq(t,q)) - 0.5 * posq(t,q) * log(det(2*pi*exp(1)*posCovEq(:,:,q,t)));
        end
    end
end

fVal = fvq + fvA + 0.5*fvE + fvH;
end
