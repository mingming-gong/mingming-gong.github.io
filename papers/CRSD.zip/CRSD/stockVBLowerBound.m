function fVal = stockVBLowerBound(X, A, w, posqi, posMeanE, posCovE, posCovE0, mus, sigmas, SigmaHat, numLag, Lambda)
% The negative lower bound function value

[dim, N] = size(X);
% marginal posterior of q
mode = 'complex';

ws = repmat(w, [numLag, 1, N-1]);
fvq = -sum(log(ws(:)).*posqi(:));
posqii = posqi(:);
posqii = posqii(posqii~=0);
fvH1 = sum(log(posqii(:)).*posqii(:));

if strcmp(mode, 'complex')
    fvA = 0;
    for t = 1:N-1
        fvA = fvA + functionValueA(X(:,t+1), X(:,t), A, posMeanE(:,t), posCovE(:,:,t), numLag, Lambda, 0);
    end
    
    fvE = 0;
    for t = 1:N-1
        for i = 1:size(posqi,1)
            for j =1:size(posqi,2)
                fvE = fvE + posqi(i,j,t)*((posCovE(i,i,t)-2*posMeanE(i,t)*mus(i,j)+mus(i,j)^2)/(sigmas(i,j)^2)+2*log(sigmas(i,j)));
            end
%             fvE = fvE + (posCovE(i,i,t))/SigmaHat(i,i,t) + log(SigmaHat(i,i,t)) + log(2*pi);
        end
    end
    
    fvH2 = 0;
    for t = 1:N-1
        fvH2 = fvH2 - 0.5*log(det(2*pi*exp(1)*posCovE0(:,:,t)));
    end
    fVal = fvq + fvA + 0.5*fvE + fvH2 + fvH1;
else
    loglik = 0;
    Atilde = atilde(A, dim, numLag);
    for t = 1:N-1
        mu = A^numLag * X(:,t);
        U = Atilde * SigmaHat(:,:,t) * Atilde' + Lambda;
        loglik = loglik + 0.5*(X(:,t+1)-mu)'*inv(U)*(X(:,t+1)-mu) +log((2*pi)^(dim/2)*det(U)^0.5) ...
            - 0.5*(log(2*pi)*numLag*dim+ sum(log(diag(SigmaHat(:,:,t)))))+sum(sum(posqi(:,:,t).*log(sigmas)));
    end
    fVal = fvq + loglik + fvH1;
end
end