function marginalPosq = marginalPosQ(posq, dim, numLag, numGauss, qidMat, initial)
% Marginal posterior of q

T = size(posq, 1);
if initial == 1
    marginalPosq = zeros(dim*(2*numLag-1), numGauss, T);
else
    marginalPosq = zeros(dim*numLag, numGauss, T);
end
for t = 1:T
    for i = 1:size(marginalPosq,1)
        for j = 1:size(marginalPosq,2)
            posqt = posq(t,:);
            ind = qidMat(:,i)==j;
            marginalPosq(i,j,t) = sum(posqt(ind));
        end
    end
end
end