function prob = gaussian(x, mu, Sigma)
% probability of Gaussian distribution

prob = (2*pi)^(-size(x,1)*0.5) * det(Sigma)^-0.5 * exp(-0.5*(x-mu)'*inv(Sigma)*(x-mu));
end