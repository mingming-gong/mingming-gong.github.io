function [fA, dfA] = fStockGradientA(A, X, posMeanE, posCovE, pars)
% Calculate function value and gradient of A
% setenv('LD_LIBRARY_PATH', '/home/mgong/Copy/MATLAB/gsl/lib');
N = size(X,2);
dim = pars.dim;
numLag = pars.numLag;
Lambda = pars.Lambda;
A = reshape(A, dim, dim);
fA = zeros(1, N-1);
% dfA = zeros(size(A,1), size(A,2), N-1);

for t = 1:N-1
    fA(t) = functionValueA(X(:,t+1), X(:,t), A, posMeanE(:,t), posCovE(:,:,t), numLag, Lambda, 0); 
%     dfA(:,:,t) = gradientA0(X(:,t+1), X(:,t), A, posMeanE(:,t), posCovE(:,:,t), dim, numLag, Lambda);
end
dfA = gradientA(X(:,2:end), X(:,1:end-1), A, posMeanE, posCovE, dim, numLag, Lambda); % c++ implementation
fA = sum(fA);
dfA = sum(dfA,3);
dfA = dfA(:);
end

function gradA = gradientA0(xtp1, xt, A, posMeanE, posCovE, dim, numLag, Lambda)
% Calculate the gradient of A

Atilde = atilde(A, dim, numLag);
if numLag == 1
    gradA1 = -2 * (Lambda\(xtp1-A^numLag*xt)*xt');
    gradA2 = -(Lambda\Atilde*posMeanE*xt');
else
    
    gradA1 = zeros(size(A,1), size(A,2));
    gradA1Left = -2 * (Lambda\(xtp1-A^numLag*xt)*xt')';
    
    for i = 1:size(A,1)
        for j = 1:size(A,2)
            J = zeros(size(A));
            J(i,j) = 1;
            gradAk = zeros(size(A));
            for r = 0:numLag-1
                gradAk = gradAk + A^r*J*A^(numLag-1-r);
            end
            gradA1(i,j) = sum(diag(gradA1Left*gradAk));
        end
    end
    
    gradA2 = zeros(size(A,1), size(A,2));
    gradA2Left = -(Lambda\Atilde*posMeanE*xt')';
    for i = 1:size(A,1)
        for j = 1:size(A,2)
            J = zeros(size(A));
            J(i,j) = 1;
            gradAk = zeros(size(A));
            for r = 0:numLag-1
                gradAk = gradAk + A^r*J*A^(numLag-1-r);
            end
            gradA2(i,j) = sum(diag(gradA2Left*gradAk));
        end
    end
end

if numLag == 1
    gradA3 = zeros(size(A,1),size(A,2));
    gradA4 = zeros(size(A,1),size(A,2));
    
elseif numLag == 2
    gradA3 = Lambda\(xtp1 - A^numLag*xt) * posMeanE(dim+1:2*dim)';
    gradA4 = zeros(size(A,1),size(A,2));
    for i = 1:size(A,1)
        for j = 1:size(A,2)
            J = zeros(size(A));
            J(i,j) = 1;
            gradAij = [zeros(dim,dim),Lambda\J;J'/Lambda, (A'/Lambda)*J+(J'/Lambda)*A];
            gradA4(i,j) = sum(diag(posCovE * gradAij));
        end
    end
else
    gradA3 = zeros(size(A,1),size(A,2));
    for l = 1:numLag-1
        gradA3Left = ((Lambda \ (xtp1 - A^numLag*xt)) * posMeanE(l*dim+1:(l+1)*dim)')';
        for i = 1:size(A,1)
            for j = 1:size(A,2)
                J = zeros(size(A));
                J(i,j) = 1;
                gradAl = zeros(size(A));
                for r = 0:l-1
                    gradAl = gradAl + A^r*J*A^(l-1-r);
                end
                gradA3(i,j) = gradA3(i,j) + sum(diag(gradA3Left*gradAl));
            end
        end
    end
%     gradA4 = zeros(size(A,1),size(A,2));
%     gradAij = zeros(numLag*dim,numLag*dim,dim^2);
%     for i = 1:size(A,1)
%         for j = 1:size(A,2)
%             J = zeros(size(A));
%             J(i,j) = 1;
%             gradAij(:,:,(i-1)*dim+j) = gradAijU(A, Lambda, dim, numLag, J);
%             gradA4(i,j) = trace(posCovE * gradAij(:,:,(i-1)*dim+j));
%         end
%     end
    gradA4 = zeros(size(A,1),size(A,2));
    gradAijs = gradAU(A, Lambda, dim, numLag);
    for i = 1:dim
        for j = 1:dim
            gradA4(i,j) = sum(diag(posCovE * gradAijs(:,:,(i-1)*dim+j)));
        end
    end
end
gradA = 0.5 * (gradA1 - 2 * (gradA2 + gradA3) + gradA4);
end

function gradAijs = gradAU(A, Lambda, dim, numLag)
% Calculate the derivative of U with respect to Aijs, optimized
gradAijs = zeros(dim*numLag, dim*numLag, dim^2);
gradAijUmn1 = zeros(dim,dim,dim^2);
gradAijUmn2 = zeros(dim,dim,dim^2);
for m = 0:numLag-1
    LambdaAm = ((A^m)'/Lambda);
    for n = m:numLag-1
        LambdaAn = Lambda\(A^n);
        gradAijUmn1Left = zeros(dim,dim,dim^2);
        for k = 1:dim
            for l = 1:dim
                gradAijUmn1Left(:,k,(k-1)*dim+l) = LambdaAn(:,l);
            end
        end
        
        for i = 1:dim
            for j = 1:dim
                gradAm = zeros(size(A));
                for r = 0:m-1
                    Ar = A^r;
                    Amr = A^(m-1-r);
                    gradAm =  gradAm + Ar(:,i)*Amr(j,:);
                end
                for k = 1:dim
                    for l = 1:dim
                        gradAijUmn1LeftTemp = gradAijUmn1Left(:,:,(k-1)*dim+l)' * gradAm;
                        gradAijUmn1(k,l,(i-1)*dim+j) = sum(diag(gradAijUmn1LeftTemp));
                    end
                end
            end
        end
        
        gradAijUmn2Left = zeros(dim,dim,dim^2);
        for k = 1:dim
            for l = 1:dim
                gradAijUmn2Left(:,l,(k-1)*dim+l) = LambdaAm(k,:)';
            end
        end
        for i = 1:dim
            for j = 1:dim
                gradAn = zeros(dim,dim);
                for r = 0:n-1
                    Ar = A^r;
                    Anr = A^(n-1-r);
                    gradAn = gradAn + Ar(:,i) * Anr(j,:);
                end
                for k = 1:dim
                    for l = 1:dim
                        gradAijUmn2LeftTemp = gradAijUmn2Left(:,:,(k-1)*dim+l)' * gradAn;
                        gradAijUmn2(k,l,(i-1)*dim+j) = sum(diag(gradAijUmn2LeftTemp));
                    end
                end
            end
        end
        if m==n
            gradAijs(m*dim+1:(m+1)*dim,n*dim+1:(n+1)*dim,:) = 0.5*(gradAijUmn1 + gradAijUmn2);
        else
            gradAijs(m*dim+1:(m+1)*dim,n*dim+1:(n+1)*dim,:) = gradAijUmn1 + gradAijUmn2;
        end
    end
end
for i = 1:dim^2
    gradAijs(:,:,i) = gradAijs(:,:,i)'+gradAijs(:,:,i);
end
end
