function [predict_label accuracy model C_opt gamma_opt] = svm_wrap(gamma, C, X, Y, Xtst, Ytst, beta)

model_tmp = zeros(length(gamma), length(C));
for i=1:length(gamma)
    for j=1:length(C)
        model_tmp(i,j) = svmtrain(beta, Y, X, ['-v 5 -g ' num2str(gamma(i)) ' -c ' num2str(C(j))]); %  2*Y-1
    end
    %     [val, Ind_val] = max(model_GTS2_tmp);
end
[hh, ii] = max(model_tmp);
[gg, jj] = max(hh);

if jj==1 | jj==length(C) | ii(jj) ==1 | ii(jj) == length(gamma)
    fprintf('Parameter value might be too big or small. \n'); %pause;
end
C_opt = C(jj);
gamma_opt = gamma(ii(jj));

model = svmtrain(beta, Y, X, ['-g ' num2str(gamma(ii(jj))) ' -c ' num2str(C(jj))]); %2*Y-1
% model_unweighted = svmtrain(ones(m, 1), Y_total+1, X);
[predict_label, accuracy, conf_test] = svmpredict(Ytst, Xtst, model);  % 2*Ytst-1

