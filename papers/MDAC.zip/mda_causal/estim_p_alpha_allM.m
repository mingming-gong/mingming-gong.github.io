function [PY alpha eta p_max Y_predict accuracy] = estim_p_alpha_allM(X, Y, Xtst, Ytst, sigma,lambda_M2,Class_Method)
% note that possible values of Y are 1, 2, 3...

% Controlling variables

% now one needs to input Class_Methods as an argument.
% % which classification method to use: 1: importance weighting; 2: generative; 3:
% % distribution-weighted; 4: all
% Class_Method = 1;

Scheme_M2 = 1;
Max_nsamples_noDR = 300;
Thresh = 1E-5;
epsilon = 0.05;
% which method is used for SVD
If_eigdec = 0;
If_eigs = 1;
If_plot = 0;
If_comb_dstr_when_M3 = 1;
If_simple_rule_when_M3 = 1; % uses the "simple adaptation" rule proposed by Mansour et al. (2008) 
                            %when applying approach 3: "Classification by weighted combination of source classifiers"?
If_alpha_must_positive = 0; % are all coefficients (alpha_{ij}) constrained to be nonnegative?
If_py_constrained = 0;
if length(unique(Ytst))>4
    If_py_constrained = 0; % are p(y_i) constrained to lie between max(p_i) and min(p_i) on source domains?
end

% the big kernel matrix for X
n = length(X);
Dim = size(X{1},2);
C = length(unique(Y{1}));
XX = [];
YY = [];
% also construct F
nsamples = 0;
ntestsample = size(Xtst,1);
for i=1:n
    nsamples = nsamples + length(Y{i});
end
F = zeros(nsamples, n*C);
current_sample = 1;

for i = 1:n
    for j = 1:C
        m_all(i,j) = sum(Y{i}==j);
        XX = [XX; X{i}(Y{i}==j,:)];
        YY = [YY; Y{i}(Y{i}==j,:)];
        F(current_sample:current_sample + m_all(i,j)-1, (i-1)*C+j) = 1/m_all(i,j);
        current_sample = current_sample + m_all(i,j);
    end
end

% XX = XX - repmat(mean(XX),current_sample-1,1);
% XX = XX * diag(1./std(XX));

% now construct the kernel matrix
mean_std_x = mean(std(XX));
% KK = rbf_dot(XX,XX,sigma*mean_std_x,0);
% KK2 = rbf_dot(XX,Xtst,sigma*mean_std_x,0);
KK = rbf_dot(XX,XX,sigma*mean_std_x);
KK2 = rbf_dot(XX,Xtst,sigma*mean_std_x);
% construct A (H) and b (f)
H = F' * KK * F;
f = -F' * KK2 * ones(ntestsample,1)/ntestsample;

% quadratic programming
options = optimset('quadprog');
options = optimset('MaxIter', 5000); % 5000
Aeq = ones(1,n*C);
beq = [1];
if ~If_py_constrained % do NOT constrain p(y_i) to lie between min(p(y_i)) and max(p(y_i))
    AA = -repmat(eye(C),1,n);
    bb = zeros(C,1);
else % constrain p(y_i) to lie between min(p(y_i)) and max(p(y_i))
    % maximum
    AA = repmat(eye(C),1,n);
    bb = max( diag(1./sum(m_all,2)) * m_all )';
    % minimum
    AA = [];bb = [];
    AA = [AA; -repmat(eye(C),1,n)];
    bb = [bb; -0.5*min( diag(1./sum(m_all,2)) * m_all )'];
%     bb = [bb;-0.01*ones(C,1)];
end

if If_alpha_must_positive
    LB = zeros(n*C,1);
else
    LB = ones(n*C,1)*(-0.3);
end
UB = ones(n*C,1)*10; % 1000

% X=QUADPROG(H,f,A,b,Aeq,beq,LB,UB) attempts to solve the quadratic programming problem:
%              min 0.5*x'*H*x + f'*x
% subject to:  A*x <= b
%              Aeq*x = beq
%              LB <= x <= UB

fprintf('solving quadprog for betas...\n');
[beta_t,FVAL,EXITFLAG] = quadprog(H,f,AA,bb,Aeq,beq,LB,UB,[],options);

for j=1:C
    PY(j) = sum(beta_t(j:C:length(beta_t)));
    alpha(j,:) = beta_t(j:C:length(beta_t))' / PY(j);
end
% PY
% alpha
% Kt is used by every method
Kt = rbf_dot(Xtst,Xtst,sigma*mean_std_x);
%% now apply the classification approach "Classification by generative modeling"
if Class_Method == 2 | Class_Method == 4
    % Kt = rbf_dot(Xtst,Xtst,sigma*mean_std_x,0);
    
    if ntestsample < Max_nsamples_noDR
        H_M2 = zeros(C*ntestsample, C*ntestsample);
        f_M2 = zeros(ntestsample*C,1);
        A_M2 = zeros(ntestsample*C,ntestsample*C);
        b_M2 = zeros(ntestsample*C,1);
        % the transformation matrix
        if Scheme_M2 == 2
            Q = Kt * pdinv(Kt + lambda_M2 * eye(ntestsample));
            c0 = 1/C * ones(ntestsample *C,1);
        else
            Q = Kt;
            c0 = repmat(pdinv(Kt+1E-5*eye(ntestsample)) * ones(ntestsample,1), C,1);
        end
        Col_Q = ntestsample * C;
        
    elseif Scheme_M2 == 2
        % dimensionality reduction for computational efficiency
        pdinv_Kt = pdinv(Kt + lambda_M2 * eye(ntestsample));
        [UU1,SS1,VV1] = svd(Kt *pdinv_Kt);
        eig1 = diag(SS1);
        II1 = find(eig1 > max(eig1) * Thresh);
        Q = Kt*pdinv_Kt * VV1(:,II1);
        c0 = [];
        for j=1:C
            c0 = [c0; pdinv(Q'*Q) * Q'* (1/C*ones(ntestsample,1))];
        end
        Col_Q = size(Q,2) * C;
        
        H_M2 = zeros(Col_Q,Col_Q);
        f_M2 = zeros(Col_Q,1);
        A_M2 = zeros(ntestsample*C,Col_Q);
        b_M2 = zeros(ntestsample*C,1);
    elseif Scheme_M2 == 1
        %     [UU1,SS1,VV1] = svds(Kt,300);
        if If_eigdec
            [SS1, UU1] = eigdec(Kt, min(ntestsample,400));
            eig1 = SS1;
        elseif If_eigs
            [UU1, SS1] = eigs(Kt, min(ntestsample,400));
            eig1 = diag(SS1);
        end
        II1 = find(eig1 > max(eig1) * Thresh);
        Q = UU1(:,II1) * diag(sqrt(eig1(II1)));
        c0 = [];
        for j=1:C
            c0 = [c0; pdinv(Q'*Q) * Q'* (1/C*ones(ntestsample,1))];
        end
        Col_Q = size(Q,2) * C;
        
        H_M2 = zeros(Col_Q,Col_Q);
        f_M2 = zeros(Col_Q,1);
        A_M2 = zeros(ntestsample*C,Col_Q);
        b_M2 = zeros(ntestsample*C,1);
    end
    
    
    for j=1:C
        if Scheme_M2 == 1 & ntestsample < Max_nsamples_noDR
            H_M2((j-1)*ntestsample + 1: j*ntestsample, (j-1)*ntestsample + 1: j*ntestsample) = Kt^3 + ntestsample^2 * lambda_M2 * Kt;
        elseif Scheme_M2 == 1 & ntestsample >= Max_nsamples_noDR
            H_M2((j-1)*Col_Q/C + 1: j*Col_Q/C, (j-1)*Col_Q/C + 1: j*Col_Q/C) = Q'*Kt*Q + ntestsample^2 * lambda_M2 * eye(Col_Q/C);
        elseif Scheme_M2 == 2 & ntestsample < Max_nsamples_noDR
            H_M2((j-1)*ntestsample + 1: j*ntestsample, (j-1)*ntestsample + 1: j*ntestsample) = Q'*Kt*Q;
        else
            H_M2((j-1)*Col_Q/C + 1: j*Col_Q/C, (j-1)*Col_Q/C + 1: j*Col_Q/C) = Q'*Kt*Q;
        end
        tmp = zeros(ntestsample,1);
        for i=1:n
            if j==1
                begin_ind = sum(sum(m_all(1:i-1,:))) +1;
            else
%                 begin_ind = sum(sum(m_all(1:i-1,:))) + m_all(i,j-1)+1;
                begin_ind = sum(sum(m_all(1:i-1,:))) + sum(m_all(i,1:j-1))+1;
            end
            tmp = tmp + sum(KK2(begin_ind:begin_ind+m_all(i,j)-1,:))'*alpha(j,i)/m_all(i,j);
        end
        if ntestsample < Max_nsamples_noDR
            f_M2((j-1)*ntestsample + 1: j*ntestsample, 1) = -PY(j) * ntestsample * Kt * tmp;
            A_M2((j-1)*ntestsample + 1: j*ntestsample, (j-1)*ntestsample + 1: j*ntestsample) = -Kt;
        else
            f_M2((j-1)*Col_Q/C + 1: j*Col_Q/C, 1) = -PY(j) * ntestsample * Q' * tmp;
            A_M2((j-1)*ntestsample + 1: j*ntestsample, (j-1)*Col_Q/C + 1: j*Col_Q/C) = -Q;
        end
    end
    % equality constraints
    % \eta = Q * c
    A_eq_M2 = - repmat(eye(ntestsample),1,C) * A_M2;
    b_eq_M2 = ones(ntestsample,1);
    % transform the euqlity constraints to inequality ones
    A_M2_all = [A_M2; A_eq_M2; -A_eq_M2];
    b_M2_all = [b_M2; (1+epsilon)*ones(size(A_eq_M2,1),1); (1-epsilon)*ones(size(A_eq_M2,1),1)];
    
    % solve the QP problem
    fprintf('solving quadprog for gammas (M2)...\n');
    [c_eta,FVAL,EXITFLAG] = quadprog(H_M2,f_M2,A_M2_all,b_M2_all,[],[],-1E3*ones(Col_Q,1),1E3*ones(Col_Q,1),...
        c0,options);
    % without the equality constraint: try
    % [c_eta,FVAL,EXITFLAG] = quadprog(H_M2,f_M2,[],[],[],[],-1E3*ones(Col_Q,1),1E3*ones(Col_Q,1),...
    %     c0,options);
    
    
    % find eta
    eta = reshape(-A_M2 * c_eta, ntestsample, C);
    [p_max Y_predict2] = max(eta, [], 2);
    accuracy2 = sum(Y_predict2==Ytst)/length(Ytst);
    if Class_Method == 2
        Y_predict = Y_predict2';
        accuracy = accuracy2;
    else
        Y_predict(2,:) = Y_predict2';
        accuracy(2) = accuracy2;
    end
    
    if If_plot
        figure, hold on;
        plot(Xtst(Y_predict2==1,1), Xtst(Y_predict2==1,2), 'go')
        plot(Xtst(Y_predict2==2,1), Xtst(Y_predict2==2,2), 'bo')
        title('Method 2');
    end
end

%% now apply the classification approach "weigh_sample"
if Class_Method == 1 | Class_Method == 4
    % first find the weights
    beta_class = zeros(size(XX,1),1);
    for j=1:C
        for i=1:n
            if j==1
                begin_ind = sum(sum(m_all(1:i-1,:))) +1;
            else
%                 begin_ind = sum(sum(m_all(1:i-1,:))) + m_all(i,j-1)+1;
                 begin_ind = sum(sum(m_all(1:i-1,:))) + sum(m_all(i,1:j-1))+1;
            end
            beta_class(begin_ind:begin_ind+m_all(i,j)-1) = alpha(j,i)/m_all(i,j) * PY(j);
        end
    end
    beta_class = beta_class * length(YY);
    
    % run SVM
    % C_M1 = [1/2^5 1/2^3 1/2 2 2^3 2^5 2^7 2^9] * 2^9,
%     C_M1 = [1/2^5 1/2 2^3 2^7 2^9] * 2^9; % Changed on May 31 for m1
%     C_M1 = [1/2^3 2^1 2^6 2^9 2^12 2^15] * 2^9; % Changed on May 31 for m1
    %     C_M1 = [1/2 2 2^3 2^5 2^7 2^9] * 2^9,
    % gamma_M1 = 1/Dim * [1/4^2 1/4 1 4 4^2 4^3 4^4 4^5] * 1/4^2; % Dim is the dimensionality of the features
%     gamma_M1 = 1/Dim * [1/4^2 1 4^2  4^4 4^5] * 1/4^2; % Dim is the dimensionality of the features % Changed on May 31 for m1
%     gamma_M1 = 1/Dim * [1/4^1 4^2  4^5 4^8 4^10] * 1/4^2; % Dim is the dimensionality of the features % Changed on May 31 for m1
    %     gamma_M1 = 1/Dim * [1/4 1 4 4^2 4^3 4^4] * 1/4^2; % Dim is the dimensionality of the features
    C_M1 = [1/2^9 1/2^7 1/2^5 1/2 2^3 2^7 2^9 2^11 2^13] * 2^9;
    gamma_M1 = 1/Dim * [1/4^9 1/4^7 1/4^5 1/4^2 1 4^2  4^4 4^5] * 1/4^2;
    [Y_predict1 accuracy1 model C_opt gamma_opt] = svm_wrap(gamma_M1, C_M1, XX, YY, Xtst, Ytst, beta_class);
    if Class_Method == 1
        Y_predict = Y_predict1;
        accuracy = accuracy1;
    else
        Y_predict(1,:) = Y_predict1';
        accuracy(1) = accuracy1(1);
    end
    eta = []; p_max = [];
    if If_plot
        figure, hold on;
        plot(Xtst(Y_predict1==1,1), Xtst(Y_predict1==1,2), 'go')
        plot(Xtst(Y_predict1==2,1), Xtst(Y_predict1==2,2), 'bo')
        title('Method 1');
    end
end


%% now apply the classification approach "Classification by weighted combination of source classifiers"
if Class_Method == 3 | Class_Method == 4
    
    % should we perform the dstribution weighted hypothesis combination
    % rule?
    if If_comb_dstr_when_M3
        current_sample = 1;
        F = zeros(nsamples, n);
        
        for i = 1:n
            mi(i) = size(Y{i},1);
            F(current_sample:current_sample + mi(i)-1, i) = 1/mi(i);
            current_sample = current_sample + mi(i);
        end
        
        % construct A (H) and b (f)
        H = F' * KK * F;
        f = -F' * KK2 * ones(ntestsample,1)/ntestsample;
        Aeq = ones(1,n);
        beq = [1];
        LB = ones(n,1)*0;
        UB = ones(n,1)*1; % 1000
        
        fprintf('solving quadprog for lambda (for distribution weighted combination rule)...\n');
        [lambda_t,FVAL,EXITFLAG] = quadprog(H,f,[],[],Aeq,beq,LB,UB,[],options);
    end
    
    % first, estimate the weights gamma
    if ntestsample >= Max_nsamples_noDR
        if Class_Method~=4
            %     [UU1,SS1,VV1] = svds(Kt,300);
            if If_eigdec
                [SS1, UU1] = eigdec(Kt, min(ntestsample,400));
                eig1 = SS1;
            elseif If_eigs
                [UU1, SS1] = eigs(Kt, min(ntestsample,400));
                eig1 = diag(SS1);
            end
            II1 = find(eig1 > max(eig1) * Thresh);
            Q = UU1(:,II1) * diag(sqrt(eig1(II1)));
        end
        c0_M3 = pdinv(Q'*Q) * Q'* ones(ntestsample,1);
        
        % regularization
        H_M3 = Q'*Kt*Q + ntestsample^2 * lambda_M2 * eye(size(Q,2));
    else
        Q = Kt;
        H_M3 = Q'*Kt*Q + ntestsample^2 * lambda_M2 * Kt;
        c0_M3 = pdinv(Kt+1E-5*eye(ntestsample)) * ones(ntestsample,1);
    end
    AA_M3 = - Q;
    bb_M3 = zeros(ntestsample,1);
    % upper bound of gamma is 6
    AA_M3 = [AA_M3; Q];
    bb_M3 = [bb_M3; 6*ones(ntestsample,1)];
    
    AA_M3 = [AA_M3; -ones(1,ntestsample)*Q; ones(1,ntestsample)*Q];
    bb_M3 = [bb_M3; -(1-epsilon)*ntestsample; (1+epsilon)*ntestsample];
    LB = -1E2 * ones(size(Q,2),1);
    UB = 1E2 * ones(size(Q,2),1);
    PY_pred_source = zeros(C,ntestsample,n); % PY from each source classifier
%         gamma_SVM = 1/Dim * [1/4^2 1/4 1 4 4^3  4^5] * 1/4^2;
%         C_SVM = [1/2^5 1/2^3 1/2 2 2^3 2^5 2^7 2^9] * 2^9,
    
    %parameter for flow data
    gamma_SVM = 1/Dim * [1/4^11 1/4^9 1/4^6 1/4^4 1/4^2 1 4^2 4^4 4^5] * 1/4^2;
    C_SVM = [1/2^7 1/2^5 1/2 2^3 2^7 2^9 2^11] * 2^9;
    
    gamma = ones(n,ntestsample);
    for i=1:n
        Ind_x_source = sum(sum(m_all(1:i-1,:)))+1: sum(sum(m_all(1:i,:)));
        f_M3 = - ntestsample/sum(m_all(i,:)) * rbf_dot(Xtst,XX(Ind_x_source,:),sigma*mean_std_x) * ones(sum(m_all(i,:)),1);
        fprintf('solving quadprog for gammas...\n');
        [gamma_t,FVAL,EXITFLAG] = quadprog(H_M3,Q'*f_M3,AA_M3,bb_M3,[],[],LB,UB,c0_M3,options);
        gamma(i,:) = (Q*gamma_t)'; % gamma_j(i,;) = alpha(j,i)*PY(j)/(m_all(i,j)/sum(m_all(i,:))) * gamma(i,:);
        % classifier from each source domain
        [predict_label accuracy0 model C_opt gamma_opt prob_out] = svm_wrap_prob(gamma_SVM, C_SVM,...
            XX(Ind_x_source,: ), YY(Ind_x_source,: ), Xtst, Ytst, ones(sum(m_all(i,:)),1));
        PY_pred_source(:,:,i) = prob_out';
        %         for k=1:ntestsample
        %             PY_pred_source(predict_label(k),k,i) = 1;
        %         end
    end
    % final decision by classifier combination
    % wighted combination
    PY_X_final = zeros(C,ntestsample);
    for j=1:C
        for i=1:n
            gamma_j = alpha(j,i)*PY(j)/(m_all(i,j)/sum(m_all(i,:))) * gamma(i,:);
            PY_X_final(j,:) = PY_X_final(j,:) + gamma_j .* PY_pred_source(j,:,i);
        end
    end
    %     figure, imagesc(PY_X_final); colorbar
    [p_max Y_predict3] = max(PY_X_final);
    % Y_predict3 = Y_predict3';
    accuracy3 = sum(Y_predict3'==Ytst)/length(Ytst);
    if Class_Method == 3
        Y_predict = Y_predict3;
        accuracy = accuracy3;
    else
        Y_predict(3,:) = Y_predict3;
        accuracy(3) = accuracy3;
    end
    eta = [];
    % using the distribution weighted combination rule
    if If_comb_dstr_when_M3
        PY_X_final_comb = zeros(C,ntestsample);
        for j=1:C
            for i=1:n
                % gamma_j = alpha(j,i)*PY(j)/(m_all(i,j)/sum(m_all(i,:))) * gamma(i,:);
                %         gamma_j = 1/n * gamma(i,:);
                gamma_j = lambda_t(i) * gamma(i,:);
                PY_X_final_comb(j,:) = PY_X_final_comb(j,:) + gamma_j .* PY_pred_source(j,:,i);
            end
        end
        %     figure, imagesc(PY_X_final); colorbar
        [p_max Y_predict6] = max(PY_X_final_comb);
        Y_predict(6,:) = Y_predict6';
        accuracy(6) = sum(Y_predict6'==Ytst)/length(Ytst);
        
        % uniform combination rule
        PY_X_final_unif = 1/n * sum(PY_pred_source,3);
        [p_max Y_predict7] = max(PY_X_final_unif);
        Y_predict(7,:) = Y_predict7;
        accuracy(7) = sum(Y_predict7'==Ytst)/length(Ytst);
    end
    
    % Simple adaptation rule (distribution equally weighted
    if If_simple_rule_when_M3
        p_kde = zeros(n,ntestsample);
        start_row =1;
        for i=1:n
            p_kde(i,:) = sum(KK2(start_row: start_row+sum(m_all(i,:))-1,:))/sum(m_all(i,:));
            start_row = start_row + sum(m_all(i,:));
        end
        p_kde = p_kde ./ repmat(sum(p_kde), n, 1);
        PY_X_final_simple = zeros(C,ntestsample);
        
        for j=1:C
            for i=1:n
                PY_X_final_simple(j,:) = PY_X_final_simple(j,:) + p_kde(i,:) .* PY_pred_source(j,:,i);
            end
        end
        [p_max Y_predict8] = max(PY_X_final_simple);
        Y_predict(8,:) = Y_predict8';
        accuracy(8) = sum(Y_predict8'==Ytst)/length(Ytst);
    end
    
    if If_plot
        figure, hold on;
        plot(Xtst(Y_predict3==1,1), Xtst(Y_predict3==1,2), 'go')
        plot(Xtst(Y_predict3==2,1), Xtst(Y_predict3==2,2), 'bo')
        title('Method 3');
    end
end

if Class_Method == 4
    [Y_predict4 accuracy4 model C_opt gamma_opt] = svm_wrap(gamma_M1, C_M1, XX, YY, Xtst, Ytst, ones(size(YY)));
    accuracy(4) = accuracy4(1);
    Y_predict(4,:) = Y_predict4';
end
% then train the classifiers on the source domains
% combine them...
