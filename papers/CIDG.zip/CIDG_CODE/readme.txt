%Code for "Domain Generalization via Conditional Invariant Representations".
%toy_demo contains the experiment on one toy data


2018.05.03
Ya Li
muziyiye@mail.ustc.edu.cn