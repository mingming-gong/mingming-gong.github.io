function [B, A] = CIDG(X, Y, beta, delta, gamma, epsilon, kernel, sigma)
% implementation of scatter component analysis
% X: cell, each element corresponds to the data of a domain
% Y: cell, each element corresponds to the label of a domain, the size of Y
%beta, delta, gamma: trade-off parameters
%epsilon can be set as a small constant
%kernel: 'linear' or 'rbf'
%sigma: parameter of kernel rbf
%A: eigenvalues
%B: transformation matrix
%% Code for "Domain Generalization via Conditional Invariant Representations".
%% Author: Ya Li 2018.05.03
%*************************************************************************
n_domain = length(X);
d = size(X{1}, 2);
n_total = 0;
nper_domain = [0];
count = 0;
for i =1:n_domain
    n_total = n_total + size(X{i}, 1);
    count = count + size(X{i}, 1);
    nper_domain = [nper_domain count];
end

X_total = [];
for i = 1:n_domain
    X_total = [X_total;X{i}];
end

%compute kernel matrix K:
if strcmp(kernel, 'linear')
    K = X_total*X_total';
elseif strcmp(kernel, 'rbf')
    dist = pdist2(X_total, X_total);
    dist = dist.^2;
    K = exp(-dist./(2*sigma*sigma));
end

%find the samples of class k and put them into cell k;
X_c = {};
Y_ALL = [];
for i = 1:n_domain
    Y_ALL = [Y_ALL; Y{i}];
end

idx = find(Y_ALL==0);

if length(idx)~=0
   num_class = length(unique(Y_ALL))-1;   %The num of classes mush begin from one
else
   num_class = length(unique(Y_ALL));
end
for i = 1:num_class
    X_c{i} = [];
end


class_index = zeros(1, n_total);
domain_index = zeros(1, n_total);
count = 1;
num_labeled = 0;
for i = 1:n_domain
    for j = 1:size(Y{i}, 1)
        temp_c = Y{i}(j);
        class_index(count) = temp_c;
        domain_index(count) = i;
        count = count + 1;
        if temp_c~= 0
            X_c{temp_c} = [X_c{temp_c}; X{i}(j, :)];
            num_labeled = num_labeled + 1;
        end
    end
end


%compute matrix P
P = zeros(n_total, n_total);
class_idx = zeros(num_labeled, 1);
count = 1;
Xc_total = [];

for i = 1:num_class
    j = 0;
    while j < size(X_c{i}, 1)
        class_idx(count) = i;
        count = count + 1;
        j = j + 1;
    end
    Xc_total = [Xc_total; X_c{i}];% stack all the labeled data
end

idx = find(class_index~=0);
P_mean = mean(K(:, idx), 2);

for j = 1:num_labeled
    class_id = class_idx(j);
    idx = find(class_index==class_id);
    temp_k = mean(K(:, idx), 2);
    P(:,j) = temp_k - P_mean;
end
P = P*P';

%compute matrix Q
Q = zeros(n_total, n_total);
for i = 1:num_class
    Q_i = zeros(n_total, size(X_c{i}, 1));
    
    idx = find(class_index==i);
    G_j = mean(K(:, idx), 2);
    
    G_ij = K(:, idx);
    Q_i = G_ij - repmat(G_j, 1, length(idx));
    
    Q = Q+Q_i*Q_i';
end

% centering the kernel matrix K
I = ones(n_total, n_total)*(1/n_total);
K = K - I*K-K*I+I*K*I;

%compute matrix new L

L2 = zeros(n_total, n_total);
temp = zeros(n_total, 1);
for j = 1:n_domain
    idx = find(domain_index==j);
    
    if j ==1
        temp = temp + mean(K(:, idx), 2);
        domain1_num = [];
        for i = 1:num_class
            idx_2 = find(class_index(idx)==i);
            domain1_num = [domain1_num; length(idx_2)];
        end
    else
        temp2 = 0;
        for i = 1:num_class
            idx_2 = find(class_index(idx)==i);
            idx_2 = idx(idx_2);
            temp2 = temp2 + sum(K(:, idx_2), 2).*(domain1_num(i)/length(idx_2));
        end
        temp = temp + temp2/sum(domain1_num);
    end
end
L_mean = temp/n_domain;


for i = 1:n_domain
    idx = find(domain_index==i);
    
    if i ==1
        Lm = mean(K(:, idx), 2);
        domain1_num = [];
        for j = 1:num_class
            idx_2 = find(class_index(idx)==j);
            domain1_num = [domain1_num; length(idx_2)];
        end
    else
        temp2 = 0;
        for j = 1:num_class
            idx_2 = find(class_index(idx)==j);
            idx_2 = idx(idx_2);
            temp2 = temp2 + sum(K(:, idx_2), 2)*(domain1_num(i)/length(idx_2));
        end
        Lm = temp2/sum(domain1_num);
    end
    L2 = L2 + (Lm-L_mean)*(Lm-L_mean)';
end

L = L2/n_domain;


%%compute matrix H
H_mean = [];
for j = 1:num_class
    temp = 0;
    for i = 1:n_domain
        idx = find(domain_index==i);
        idx_2 = find(class_index(idx)==j);
        idx_2 = idx(idx_2);
        temp = temp + mean(K(:, idx_2), 2);
    end
    H_mean = [H_mean temp/n_domain];
end

H_temp = 0;
for j = 1:num_class
    for i = 1:n_domain
        idx = find(domain_index==i);
        idx_2 = find(class_index(idx)==j);
        idx_2 = idx(idx_2);
        H_t = mean(K(:, idx_2), 2);
        H_temp = H_temp + (H_t-H_mean(:, j))*(H_t-H_mean(:, j))';
    end 
end
H = H_temp/n_domain;


%compute transformation B, note that we add W'W=B'KB as a constraint of the
%scale of the solution.
I_0 = eye(n_total);
F1 = beta*P;
F2 = (delta*L+gamma*H+K+Q+epsilon*I_0);
F = F2\F1;

[B, A] = eig(F);
B = real(B);
A = real(A);
eigvalues = diag(A);
[val, idx] = sort(eigvalues, 'descend');
B = B(:, idx);
A= diag(val);