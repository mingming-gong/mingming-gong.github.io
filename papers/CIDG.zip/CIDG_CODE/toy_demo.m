clear;
load('toy_dataX.mat');
load('toy_dataY.mat');
% shapes of dots
marks = {'*', 'o', '+', '*', 'o', '+', '*', 'o', '+'};
%colors of different classes
colors = ['r', 'g', 'b', 'r', 'g', 'b', 'r', 'g', 'b', 'r', 'g', 'b'];
%colors of different domains
colors2 = {[0.8 0.4 0], [1 0 1], [0 0.4 0.4], [0.8 0.4 0], [1 0 1], [0 0.4 0.4], [0.8 0.4 0],  [1 0 1], [0 0.4 0.4], [0.8 0.4 0], [1 0 1], [0 0.4 0.4]};


%plot souce distributions of original data in different domains
figure;
for i = 1:9
    t = fix(i/3-0.001)+1;
    label = ones(size(X{i}, 1), 1);
    gscatter(X{i}(:,1), X{i}(:, 2), label,colors2{t}, marks{t}, 5);
    hold on;
end

%plot souce distributions of original data in different classes
figure;
for i = 1:9
    t = fix(i/3-0.001)+1;
    para = [colors(i) marks{t}];
    plot(X{i}(:,1), X{i}(:, 2), para, 'MarkerSize', 5);
    hold on;
end


kernel = 'rbf';

% data of domain 1
X_all{2}= [X{1};X{2};X{3}];
Y_all{2} = [Y{1};Y{2}; Y{3}];


%data of domain 2
X_all{1} = [X{4};X{5};X{6}];
Y_all{1} = [Y{4};Y{5};Y{6}];

%data of domain 3 (as validation set)
X_t1 = [X{7};X{8};X{9}];
Y_t1 = [Y{7};Y{8};Y{9}];

%data of domain 4 (as target domain)
X_t2 = [X{10};X{11};X{12}];
Y_t2 = [Y{10};Y{11};Y{12}];


Train_data = [X_all{1};X_all{2}];
Train_label = [Y_all{1};Y_all{2}];

% classification using original data of source domains
pre_labels = knnclassify(X_t1, Train_data, Train_label);
acc_1 = length(find(pre_labels==Y_t1))/length(pre_labels);


%train CIDG using domain 3 as validation set
All_acc = zeros(5, 7, 7, 7);
for i = 1:5
    for j = 1:10
        for k = 1:7
            for q = 1:10
                beta = 0.1+(i-1)*0.2;
                delta = power(10, j-1);
                sigma = power(10, k-4);
                gamma = power(10, q-4);
                [B, A] = CIDG(X_all, Y_all, beta, delta, gamma, 0.00001, kernel, sigma);
                
                B = real(B);
                A = real(A);
                [ACC, pre_labels, Zs, Zt] = CIDG_test(B, A, X_all, Train_data, Train_label, X_t1, Y_t1, kernel, sigma, 2);
                
                All_acc(i,j,k,q) = ACC;
                fprintf('i: %d,j: %d,k: %d, acc: %d \n', i, j, k, ACC);
            end
        end
    end
end

ind = find(All_acc==max(All_acc(:)));
[m, n, x, y] = size(All_acc);
[best_i, best_j, best_k, best_q] = ind2sub([m n x y],ind(1));

best_beta = 0.1+(best_i-1)*0.2;
best_delta = power(10, best_j-1);
best_sigma = power(10, best_k-4);
best_gamma = power(10, best_q-4);

[B, A] = CIDG(X_all, Y_all, best_beta, best_delta, best_gamma, 0.00001, kernel, best_sigma);

B = real(B);
A = real(A);
[Final_ACC, pre_labels, Z_s, Z_t] = CIDG_test(B, A, X_all, Train_data, Train_label, X_t2, Y_t2, kernel, best_sigma, 2);

Z = [Z_s; Z_t];
count = [0 60 80 120 140 170 200 240 280 320];
%plot the results according to domain 
figure;
for i = 1:9
    t = fix(i/3-0.001)+1;
    para = [colors2{t} marks(t)];
    label = ones(count(i+1)-count(i), 1);
    gscatter(Z(count(i)+1:count(i+1), 1), Z(count(i)+1:count(i+1), 2), label,colors2{t}, marks{t}, 5, 'off');
    hold on;
end

%plot results according to classes
figure;
for i = 1:9
    t = fix(i/3-0.001)+1;
    para = [colors(i) marks{t}];
    plot(Z(count(i)+1:count(i+1), 1), Z(count(i)+1:count(i+1), 2), para, 'MarkerSize', 5);
    hold on;
end