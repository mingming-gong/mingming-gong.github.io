function [ACC, pre_labels, Zs, Zt] = CIDG_test(B, A, X_all, X_s, Y_s, X_t, Y_t, kernel, sigma, eig_ratio)
%A: eigenvalues
%B: transformation matrix
%X_all: train data of cell format
%X_s: train data of matrix format
%Y_s: train label of matrix format
%X_t: target domain data
%Y_t: target domain label
%kernel: 'linear' or 'rbf'
%sigma: parameter for kernel
%eig_ratio: eigvalue ratio used for test
%*************************************************************************
%% Author: Ya Li 2018.05.03
n_domain = length(X_all);
n_s = size(X_s, 1);
n_t = size(X_t, 1);

X_total = [];
for i = 1:n_domain
    X_total = [X_total; X_all{i}];
end
n_total = size(X_total, 1);


H = eye(n_total) - ones(n_total)./n_total;
H_t = eye(n_t) - ones(n_t)./n_t;
H_s = eye(n_s) - ones(n_s)./n_s;

B = real(B);
A = real(A);

if strcmp(kernel, 'rbf')
    dist = pdist2(X_total, X_t);
    dist = dist.^2;
    K_t = exp(-dist./(2*sigma*sigma));
elseif strcmp(kernel, 'linear')
    dist = pdist2(X_total, X_t);
    K_t = dist.^2;
end
K_t = H*K_t*H_t;

vals = diag(A);
ratio = [];
count = 0;
for i = 1:length(vals)
    if vals(i)<0
        break;
    end
    count = count + vals(i);
    ratio = [ratio; count];
    vals(i) = 1/sqrt(vals(i));
end
A_sqrt = diag(vals);
ratio = ratio/count;

if eig_ratio <= 1
    idx = find(ratio>eig_ratio);
    n_eigs = idx(1);
else
    n_eigs = eig_ratio;
end


Zt = K_t'*B(:, 1:n_eigs)*A_sqrt(1:n_eigs, 1:n_eigs);

dist = pdist2(X_total, X_s);
dist = dist.^2;
K_s = exp(-dist./(2*sigma*sigma));
K_s = H*K_s*H_s;

Zs = K_s'*B(:, 1:n_eigs)*A_sqrt(1:n_eigs, 1:n_eigs);

pre_labels = knnclassify(Zt, Zs, Y_s);
ACC = length(find(pre_labels==Y_t))/length(pre_labels);










